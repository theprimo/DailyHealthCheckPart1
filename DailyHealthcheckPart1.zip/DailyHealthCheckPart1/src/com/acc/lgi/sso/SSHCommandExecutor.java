package com.acc.lgi.sso;

import java.io.IOException;
import java.io.InputStream;
import java.util.StringTokenizer;

import com.jcraft.jsch.Channel;
import com.jcraft.jsch.ChannelExec;
import com.jcraft.jsch.JSch;
import com.jcraft.jsch.Session;


public class SSHCommandExecutor {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		//String host="10.64.122.17"; //PROD S1
		String host="10.64.117.15"; //UAT S1
		String user="skatta";
		String password="Aurora@123";
		String command2="cd /u01/appl/IBM/ldap/V6.2/bin;./ibmdirctl -D cn=root -w qXWLB8SS1ejruWX status";
		String command1="cd /u01/appl/IBM/ldap/V6.2/bin;free -m";
		String strMemoryUsed=null,strMemoryFree=null,strCacheUsed=null,strCacheFree=null;
		StringTokenizer str=null;
		Channel channel=null;
		Session session=null;
		String strCmdOutput;
		try{
			java.util.Properties config = new java.util.Properties(); 
			config.put("StrictHostKeyChecking", "no");
			JSch jsch = new JSch();
			session=jsch.getSession(user, host, 22);
			session.setPassword(password);
			session.setConfig(config);
			session.connect();
			System.out.println("Connected");

			channel=session.openChannel("exec");
			((ChannelExec)channel).setCommand(command2);
			channel.setInputStream(null);
			((ChannelExec)channel).setErrStream(System.err);

			InputStream in=channel.getInputStream();
			
			 channel.connect();
			 Thread.sleep(1000);
			byte[] tmp=new byte[1024];
			while(true){
				while(in.available()>0){ 
					int i=in.read(tmp, 0, 1024);
					if(i<0)break;
					strCmdOutput = new String(tmp, 0, i);
					System.out.print(strCmdOutput);
					String[] parts = strCmdOutput.split("[ ]{2,}");//.split("\\s{2,}");
					//Extract only required values from command output
					strMemoryUsed=parts[8];
					strMemoryFree=parts[9];
					strCacheUsed=parts[13];
					str = new StringTokenizer(parts[14],"Swap:");
					strCacheFree=str.nextToken().trim();
				}
				if(channel.isClosed()){
					System.out.println("exit-status: "+channel.getExitStatus());
					break;
				}
				try{
					Thread.sleep(1000);
				}
				catch(Exception e){
					System.out.println(e);
				}
			}
		}catch(Exception e){
			e.printStackTrace();
		}
		finally{
			if(null!=channel)channel.disconnect();
			if(null!=session)session.disconnect();
			System.out.println("DONE");
		}

	}

}