package com.acc.lgi.sso;

import static com.codeborne.selenide.Condition.visible;
import static com.codeborne.selenide.Selenide.$;
import static com.codeborne.selenide.Selenide.open;
import static com.codeborne.selenide.WebDriverRunner.source;
import static com.codeborne.selenide.WebDriverRunner.url;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.util.ArrayList;
import java.util.Properties;
import java.util.StringTokenizer;

import javax.xml.transform.Source;

import org.openqa.selenium.By;

import com.jcraft.jsch.Channel;
import com.jcraft.jsch.ChannelExec;
import com.jcraft.jsch.ChannelShell;
import com.jcraft.jsch.JSch;
import com.jcraft.jsch.JSchException;
import com.jcraft.jsch.Session;

public class PerformMemoryStatusCheck extends PerformHealthCheckPart1 {

	//Check all servers memory status
	public static void checkServersMemoryStatus() {
		int counter,index;
		String strHostName,strServerIP;

		try{
			rowCount=0;
			counter=1;
			for(;counter<=noOfServerTypes;counter++){
				//Write Type of servers
				columnCount = 0;
				row = sheet[sheetIndex].createRow(++rowCount);
				cell = row.createCell(++columnCount);
				switch(counter){
				case 1 : cell.setCellValue(allproperties.getProperty("LDAP1SERVERSTYPE")); break;
				case 2 : cell.setCellValue(allproperties.getProperty("WAS1SERVERSTYPE")); break;
				case 3 : cell.setCellValue(allproperties.getProperty("NLAH1SERVERSTYPE")); break;
				case 4 : cell.setCellValue(allproperties.getProperty("NLCARE1SERVERSTYPE")); break;
				case 5 : cell.setCellValue(allproperties.getProperty("NLSSOSHERPASERVERSTYPE")); break;
				case 6 : cell.setCellValue(allproperties.getProperty("SKAH1SERVERSTYPE")); break;	
				case 7 : cell.setCellValue(allproperties.getProperty("SKSSO1SERVERSTYPE")); break;	
				case 8 : cell.setCellValue(allproperties.getProperty("IESSO1SERVERSTYPE")); break;	
				case 9 : cell.setCellValue(allproperties.getProperty("HUIDCHECK1SERVERSTYPE")); break;	
				case 10 : cell.setCellValue(allproperties.getProperty("TMNGXAT1SERVERSTYPE")); break;	
				case 11 : cell.setCellValue(allproperties.getProperty("HYSTRIXCEE1SERVERSTYPE")); break;	
				}
				cell.setCellStyle(cellStyle);

				//Memory status headers to excel for each type of servers
				columnCount = 0;
				row = sheet[sheetIndex].createRow(++rowCount);
				cell = row.createCell(++columnCount);
				cell.setCellValue("Servername");
				cell.setCellStyle(cellStyle);
				cell = row.createCell(++columnCount);
				cell.setCellValue("ServerIP");
				cell.setCellStyle(cellStyle);
				cell = row.createCell(++columnCount);
				cell.setCellValue("Used memory");
				cell.setCellStyle(cellStyle);
				cell = row.createCell(++columnCount);
				cell.setCellValue("Free memory");
				cell.setCellStyle(cellStyle);
				cell = row.createCell(++columnCount);
				cell.setCellValue("(+/-) buffers/cache(USED)");
				cell.setCellStyle(cellStyle);
				cell = row.createCell(++columnCount);
				cell.setCellValue("(+/-) buffers/cache(FREE)");
				cell.setCellStyle(cellStyle);
				//Additional column for LDAP Servers running status
				if(counter==1){
					cell = row.createCell(++columnCount);
					cell.setCellValue("Server Status");
					cell.setCellStyle(cellStyle);
				}

				switch(counter){
				case 1:
					index=0;
					System.out.println("[Info]: LDAP servers memory status started");
					while(index<noOfLDAPServers){
						strHostName=allproperties.getProperty("LDAP"+Integer.toString(index+1)+"HOSTNAME");
						strServerIP=allproperties.getProperty("LDAP"+Integer.toString(index+1)+"IPADDRESS");
						openSSHNCheckMemoryStatus(strHostName,strServerIP);
						cell = row.createCell(++columnCount);
						cell.setCellValue(openSSHNcheckLDAPServerStatus(strServerIP));
						index++;
					}
					System.out.println("[Info]: LDAP servers memory status done");
					break;					
				case 2:
					index=0;
					System.out.println("[Info]: WAS servers memory status started");
					while(index<noOfWASServers){
						strHostName=allproperties.getProperty("WAS"+Integer.toString(index+1)+"HOSTNAME");
						strServerIP=allproperties.getProperty("WAS"+Integer.toString(index+1)+"IPADDRESS");
						openSSHNCheckMemoryStatus(strHostName,strServerIP);
						index++;
					}
					System.out.println("[Info]: WAS servers memory status done");
					break;
				case 3:
					index=0;
					System.out.println("[Info]: NL AH servers memory status started");
					while(index<noOfNLAHServers){
						strHostName=allproperties.getProperty("NLAH"+Integer.toString(index+1)+"HOSTNAME");
						strServerIP=allproperties.getProperty("NLAH"+Integer.toString(index+1)+"IPADDRESS");
						openSSHNCheckMemoryStatus(strHostName,strServerIP);
						index++;
					}
					System.out.println("[Info]: NL AH servers memory status done");
					break;
				case 4:
					index=0;
					System.out.println("[Info]: NL Care servers memory status started");
					while(index<noOfNLCareServers){
						strHostName=allproperties.getProperty("NLCARE"+Integer.toString(index+1)+"HOSTNAME");
						strServerIP=allproperties.getProperty("NLCARE"+Integer.toString(index+1)+"IPADDRESS");
						openSSHNCheckMemoryStatus(strHostName,strServerIP);
						index++;
					}
					System.out.println("[Info]: NL Care servers memory status done");
					break;
				case 5:
					index=0;
					System.out.println("[Info]: NL SSO servers memory status started");
					while(index<noOfNLSSOSherpaServers){
						strHostName=allproperties.getProperty("NLSSOSHERPA"+Integer.toString(index+1)+"HOSTNAME");
						strServerIP=allproperties.getProperty("NLSSOSHERPA"+Integer.toString(index+1)+"IPADDRESS");
						openSSHNCheckMemoryStatus(strHostName,strServerIP);
						index++;
					}
					System.out.println("[Info]: NL SSO servers memory status done");
					break;
				case 6:
					index=0;
					System.out.println("[Info]: SK AH servers memory status started");
					while(index<noOfSKAHServers){
						strHostName=allproperties.getProperty("SKAH"+Integer.toString(index+1)+"HOSTNAME");
						strServerIP=allproperties.getProperty("SKAH"+Integer.toString(index+1)+"IPADDRESS");
						openSSHNCheckMemoryStatus(strHostName,strServerIP);
						index++;
					}
					System.out.println("[Info]: SK AH servers memory status done");
					break;
				case 7:
					index=0;
					System.out.println("[Info]: SK SSO servers memory status started");
					while(index<noOfSKSSOServers){
						strHostName=allproperties.getProperty("SKSSO"+Integer.toString(index+1)+"HOSTNAME");
						strServerIP=allproperties.getProperty("SKSSO"+Integer.toString(index+1)+"IPADDRESS");
						openSSHNCheckMemoryStatus(strHostName,strServerIP);
						index++;
					}
					System.out.println("[Info]: SK SSO servers memory status done");
					break;
				case 8:
					index=0;
					System.out.println("[Info]: IE SSO servers memory status started");
					while(index<noOfIESSOServers){
						strHostName=allproperties.getProperty("IESSO"+Integer.toString(index+1)+"HOSTNAME");
						strServerIP=allproperties.getProperty("IESSO"+Integer.toString(index+1)+"IPADDRESS");
						openSSHNCheckMemoryStatus(strHostName,strServerIP);
						index++;
					}
					System.out.println("[Info]: IE SSO servers memory status done");
					break;
				case 9:
					index=0;
					System.out.println("[Info]: HU ID Check servers memory status started");
					String strAdminServerIP=null;
					while(index<noOfHUIDCheckServers){
						//System.out.println("Index: "+index);
						strHostName=allproperties.getProperty("HUIDCHECK"+Integer.toString(index+1)+"HOSTNAME");
						strServerIP=allproperties.getProperty("HUIDCHECK"+Integer.toString(index+1)+"IPADDRESS");
						if(index==0){
							strAdminServerIP=strServerIP;
							openSSHNCheckMemoryStatus(strHostName,strServerIP);
						}else{
							openAdminSSHNCheckMemoryStatus(strAdminServerIP,strHostName,strServerIP);
						}
						index++;
					}
					System.out.println("[Info]: HU ID Check servers memory status done");
					break;
				case 10:
					index=0;
					System.out.println("[Info]: TMNGX AT READ servers memory status started");
					while(index<noOfTMNGXATServers){
						strHostName=allproperties.getProperty("TMNGXAT"+Integer.toString(index+1)+"HOSTNAME");
						strServerIP=allproperties.getProperty("TMNGXAT"+Integer.toString(index+1)+"IPADDRESS");
						openSSHNCheckMemoryStatus(strHostName,strServerIP);
						index++;
					}
					System.out.println("[Info]: TMNGX AT READ servers memory status done");
					break;
				case 11:
					index=0;
					System.out.println("[Info]: HYSTRIX CEE servers memory status started");
					while(index<noOfHYSTRIXCEEServers){
						strHostName=allproperties.getProperty("HYSTRIXCEE"+Integer.toString(index+1)+"HOSTNAME");
						strServerIP=allproperties.getProperty("HYSTRIXCEE"+Integer.toString(index+1)+"IPADDRESS");
						openSSHNCheckMemoryStatus(strHostName,strServerIP);
						index++;
					}
					System.out.println("[Info]: HYSTRIX CEE servers memory status done");
					break;
				}
				//blank row between each type of servers status
				row = sheet[sheetIndex].createRow(++rowCount);
			}
		}catch(Exception e){
			try {
				bw.write(e.getMessage());
			} catch (IOException e1) {
				e1.printStackTrace();
			}
			System.out.println(e);
		}

	}

	//Check LDAP servers running status
	private static String openSSHNcheckLDAPServerStatus(String strServerIP) {

		String serverStatus=null;
		Channel channel=null;
		Session session=null;
		try{
			String strCmdOutput=null;
			String host=strServerIP;
			String command1=allproperties.getProperty("UNIXLDAPSTATUSCOMMANDPATH");
			String command2=allproperties.getProperty("UNIXLDAPSTATUSCOMMAND");

			JSch jsch = new JSch();
			session = jsch.getSession(unixUsername, host, 22);
			Properties config = new Properties();	
			config.put("StrictHostKeyChecking", "no");
			session.setConfig(config);;
			session.setPassword(unixPassword);
			session.connect();

			channel = session.openChannel("shell");
			channel.setInputStream(null);
			channel.setOutputStream(null);

			InputStream in = channel.getInputStream();
			OutputStream out = channel.getOutputStream();
			((ChannelShell)channel).setPtyType("vt102");
			channel.connect();

			out.write((command1).getBytes());
			out.write(("\n").getBytes());
			out.write((command2).getBytes());
			out.write(("\nexit\n").getBytes());
			out.flush();

			try{
				InputStreamReader inputReader = new InputStreamReader(in);
				BufferedReader bufferedReader = new BufferedReader(inputReader);
				String line = null;
				while((line = bufferedReader.readLine()) != null){
					strCmdOutput = line.trim();
					if(strCmdOutput.startsWith("Directory server is")){
						if(strCmdOutput.equals("Directory server is running.")){
							serverStatus="Running";
						}else{
							serverStatus="Not Running";
						}
					}
					else if((strCmdOutput).equals("logout")){
						break;
					}
				}
				bufferedReader.close();
				inputReader.close();
				in.close();

			}catch(IOException e){
				try {
					System.out.println(e);
					bw.write(e.toString());
				} catch (IOException e1) {
					e1.printStackTrace();
				}
			}
		}catch(Exception e){
			try {
				System.out.println(e);
				bw.write(e.toString());
			} catch (IOException e1) {
				e1.printStackTrace();
			}
		}
		finally{
			//System.out.println(serverStatus);
			if(null!=channel)channel.disconnect();
			if(null!=session)session.disconnect();
		}
		return serverStatus;

	}

	//check memory status of all servers thru Admin new
	private static void openAdminSSHNCheckMemoryStatus(String strAdminServerIP,String strHostName, String strServerIP) throws IOException {	
		String strMemoryUsed=null,strMemoryFree=null,strCacheUsed=null,strCacheFree=null;
		StringTokenizer str=null;
		Channel channel=null;
		Session session=null;
		byte[] tmp=null;
		String command1 = "ssh -T -o \"StrictHostKeyChecking no\" "+strServerIP;
		String command2=allproperties.getProperty("UNIXMEMORYCHECKCOMMAND");
		String host=strAdminServerIP; 
		String user=allproperties.getProperty("UNIXUSERNAME");
		String password=allproperties.getProperty("UNIXPASSWORD");;

		try{
			java.util.Properties config = new java.util.Properties(); 
			config.put("StrictHostKeyChecking", "no");
			JSch jsch = new JSch();
			session=jsch.getSession(user, host, 22);
			session.setPassword(password);
			session.setConfig(config);
			session.connect();
			try {
				Thread.sleep(2000);
			} catch (InterruptedException e1) {
				e1.printStackTrace();
			}
			channel=session.openChannel("exec");
			((ChannelExec)channel).setCommand(command1);
			channel.setInputStream(null);
			((ChannelExec)channel).setErrStream(System.err);

			InputStream in=channel.getInputStream();
			OutputStream out=channel.getOutputStream();
			((ChannelExec)channel).setErrStream(System.err);

			channel.connect();
			out.write(("wait $!\n").getBytes()); //wait for previous command completion
			out.write((command2+"\n").getBytes());
			out.write(("wait $!\n").getBytes()); //wait for previous command completion
			out.write(("logout\n").getBytes());
			out.flush();

			tmp=new byte[1024];
			while(true){
				String strCmdOutput;
				//while runs only once, because total o/p is less than 1024 bytes
				while(in.available()>0){ 
					int i=in.read(tmp, 0, 1024);
					if(i<0)break;
					strCmdOutput = new String(tmp, 0, i);
					//System.out.println(strCmdOutput);
					String[] parts = strCmdOutput.split("[ ]{2,}");//.split("\\s{2,}");
					//Extract only required values from command output
					strMemoryUsed=parts[8];
					strMemoryFree=parts[9];
					strCacheUsed=parts[13];
					str = new StringTokenizer(parts[14],"\n ");
					strCacheFree=str.nextToken().trim();
				}
				if(channel.isClosed()){
					break;
				}
				try{
					Thread.sleep(1000);
				}catch(Exception e){
					e.printStackTrace();
					try {
						bw.write(e.getMessage());
					} catch (IOException e1) {
						e1.printStackTrace();
					}
				}
			}
			if((null!=tmp)&&(null!=strMemoryUsed)){
				//write memory status results to excel
				columnCount=0;
				row = sheet[sheetIndex].createRow(++rowCount);
				cell = row.createCell(++columnCount);
				cell.setCellValue(strHostName);
				cell = row.createCell(++columnCount);
				cell.setCellValue(strServerIP);
				cell = row.createCell(++columnCount);
				cell.setCellValue(strMemoryUsed);
				cell = row.createCell(++columnCount);
				cell.setCellValue(strMemoryFree);
				cell = row.createCell(++columnCount);
				cell.setCellValue(strCacheUsed);
				cell = row.createCell(++columnCount);
				cell.setCellValue(strCacheFree);
			}			

		}catch (JSchException e) {
			e.printStackTrace();
			try {
				bw.write(e.getMessage());
			} catch (IOException e1) {
				e1.printStackTrace();
			}
		} 
		catch(Exception e){
			e.printStackTrace();
			try {
				bw.write(e.getMessage());
			} catch (IOException e1) {
				e1.printStackTrace();
			}
		}
		finally{
			//If Unix box is not up then ?
			if((null==tmp)||(null==strMemoryUsed)){
				columnCount=0;
				row = sheet[sheetIndex].createRow(++rowCount);
				cell = row.createCell(++columnCount);
				cell.setCellValue(strHostName);
				cell = row.createCell(++columnCount);
				cell.setCellValue(strServerIP);
				cell = row.createCell(++columnCount);
				cell.setCellValue("Unable to connect OR Login to the server!");
			}
			if(null!=channel)channel.disconnect();
			if(null!=session)session.disconnect();
		}
	}

	//check memory status of all servers
	private static void openSSHNCheckMemoryStatus(String strHostName, String strServerIP) {	
		String strMemoryUsed=null,strMemoryFree=null,strCacheUsed=null,strCacheFree=null;
		StringTokenizer str=null;
		Channel channel=null;
		Session session=null;
		byte[] tmp=null;
		try{
			java.util.Properties config = new java.util.Properties(); 
			config.put("StrictHostKeyChecking", "no");
			JSch jsch = new JSch();
			session=jsch.getSession(unixUsername, strServerIP, 22);
			session.setPassword(unixPassword);
			session.setConfig(config);
			session.connect();
			//System.out.println("Connected");

			channel=session.openChannel("exec");
			((ChannelExec)channel).setCommand(unixMemCheckCmd);
			channel.setInputStream(null);
			((ChannelExec)channel).setErrStream(System.err);

			InputStream in=channel.getInputStream();
			channel.connect();
			tmp=new byte[1024];
			while(true){
				String strCmdOutput;
				//while runs only once, because total o/p is less than 1024 bytes
				while(in.available()>0){ 
					int i=in.read(tmp, 0, 1024);
					if(i<0)break;
					strCmdOutput = new String(tmp, 0, i);
					//System.out.print(strCmdOutput);
					String[] parts = strCmdOutput.split("[ ]{2,}");//.split("\\s{2,}");
					//Extract only required values from command output
					strMemoryUsed=parts[8];
					strMemoryFree=parts[9];
					strCacheUsed=parts[13];
					str = new StringTokenizer(parts[14],"\n ");
					strCacheFree=str.nextToken().trim();
				}
				if(channel.isClosed()){
					//System.out.println("exit-status: "+channel.getExitStatus());
					break;
				}
				try{
					Thread.sleep(1000);
				}catch(Exception e){
					try {
						System.out.println(e);
						bw.write(e.toString());
					} catch (IOException e1) {
						e1.printStackTrace();
					}
				}
			}
			//write memory status results to excel
			columnCount=0;
			row = sheet[sheetIndex].createRow(++rowCount);
			cell = row.createCell(++columnCount);
			cell.setCellValue(strHostName);
			cell = row.createCell(++columnCount);
			cell.setCellValue(strServerIP);
			cell = row.createCell(++columnCount);
			cell.setCellValue(strMemoryUsed);
			cell = row.createCell(++columnCount);
			cell.setCellValue(strMemoryFree);
			cell = row.createCell(++columnCount);
			cell.setCellValue(strCacheUsed);
			cell = row.createCell(++columnCount);
			cell.setCellValue(strCacheFree);
		}catch (JSchException e) {
			try {
				bw.write(e.toString());
			} catch (IOException e1) {
				e1.printStackTrace();
			}
		} catch (IOException e) {
			try {
				bw.write(e.toString());
			} catch (IOException e1) {
				e1.printStackTrace();
			}
		} catch(Exception e){
			try {
				bw.write(e.toString());
			} catch (IOException e1) {
				e1.printStackTrace();
			}
		}
		finally{
			//check the Unix box is up or not ?
			if((null==tmp)){
				columnCount=0;
				row = sheet[sheetIndex].createRow(++rowCount);
				cell = row.createCell(++columnCount);
				cell.setCellValue(strHostName);
				cell = row.createCell(++columnCount);
				cell.setCellValue(strServerIP);
				cell = row.createCell(++columnCount);
				cell.setCellValue("Unable to connect to the server!");
			}
			if(null!=channel)channel.disconnect();
			if(null!=session)session.disconnect();
			//System.out.println("Done");
		}
	}

	//check memory status of servers through admin server
	private static void checkMemoryStatusThruAdminSSH_Old(String strAdminServerIP,String strHostName, String strServerIP) {	
		String strMemoryUsed=null,strMemoryFree=null,strCacheUsed=null,strCacheFree=null;
		StringTokenizer str=null;
		Channel channel2=null,channel1=null;;
		Session session=null;
		String command1 = "ssh -o \"StrictHostKeyChecking no\" "+strServerIP;
		String command2 = unixMemCheckCmd;
		byte[] tmp=null;
		try{
			java.util.Properties config = new java.util.Properties(); 
			config.put("StrictHostKeyChecking", "no");
			JSch jsch = new JSch();
			session=jsch.getSession(unixUsername,strAdminServerIP, 22);
			session.setPassword(unixPassword);
			session.setConfig(config);
			session.connect();

			channel1=session.openChannel("exec");
			channel2=session.openChannel("exec");

			((ChannelExec)channel1).setCommand(command1);
			channel1.setInputStream(null);
			((ChannelExec)channel2).setCommand(command2);
			channel2.setInputStream(null);
			((ChannelExec)channel2).setErrStream(System.err);

			//InputStream in1=channel1.getInputStream();
			channel1.connect();

			InputStream in=channel2.getInputStream();
			channel2.connect();

			tmp=new byte[1024];
			while(true){
				String strCmdOutput;
				//while runs only once, because total o/p is less than 1024 bytes
				while(in.available()>0){ 
					int i=in.read(tmp, 0, 1024);
					if(i<0)break;
					strCmdOutput = new String(tmp, 0, i);
					System.out.print(strCmdOutput);
					String[] parts = strCmdOutput.split("[ ]{2,}");//.split("\\s{2,}");
					//Extract only required values from command output
					strMemoryUsed=parts[8];
					strMemoryFree=parts[9];
					strCacheUsed=parts[13];
					str=new StringTokenizer(parts[14],"Swap:");
					strCacheFree=(str.nextToken()).trim();
				}
				if(channel2.isClosed()){
					//System.out.println("exit-status: "+channel2.getExitStatus());
					break;
				}
				try{Thread.sleep(1000);}catch(Exception ee){}
			}
			//write memory status results to excel
			columnCount=0;
			row = sheet[sheetIndex].createRow(++rowCount);
			cell = row.createCell(++columnCount);
			cell.setCellValue(strHostName);
			cell = row.createCell(++columnCount);
			cell.setCellValue(strServerIP);
			cell = row.createCell(++columnCount);
			cell.setCellValue(strMemoryUsed);
			cell = row.createCell(++columnCount);
			cell.setCellValue(strMemoryFree);
			cell = row.createCell(++columnCount);
			cell.setCellValue(strCacheUsed);
			cell = row.createCell(++columnCount);
			cell.setCellValue(strCacheFree);

		}catch (JSchException e) { try {
			bw.write(e.toString());
		} catch (IOException e1) {
			e1.printStackTrace(); }
		} catch (IOException e) { try {
			bw.write(e.toString());
		} catch (IOException e1) {
			e1.printStackTrace();}
		} catch(Exception e){ try {
			bw.write(e.toString());
		} catch (IOException e1) {
			e1.printStackTrace(); }
		}
		finally{
			//check the Unix box is up or not ?
			if((null==tmp)){
				System.out.println("Unable to connect to the server!");
			}
			if(null!=channel1)channel1.disconnect();
			if(null!=channel2)channel2.disconnect();
			if(null!=session)session.disconnect();
		}
	}

}
