package com.acc.lgi.sso;

import static com.codeborne.selenide.Condition.selected;
import static com.codeborne.selenide.Condition.visible;
import static com.codeborne.selenide.Selenide.$;
import static com.codeborne.selenide.Selenide.open;

import java.io.IOException;
import java.util.LinkedHashSet;
import java.util.LinkedList;
import java.util.List;
import java.util.Set;
import java.util.StringTokenizer;

import org.openqa.selenium.By;

import com.codeborne.selenide.SelenideElement;

public class PerformWASHealthCheck extends PerformHealthCheckPart1 {
	//Check PROD WAS Servers health check
	public static void checkWASHealthCheck() {
		try{
			consoleIndex=0;
			rowCount=0;
			//noOfWASConsoles=1;
			//Go through all WAS consoles and perform the checks
			while(consoleIndex < noOfWASConsoles) {
				columnCount = 0;

				row = sheet[sheetIndex].createRow(++rowCount);
				if(loginToWASConsole()){
					// go further
					checkWASDataSourcesConnectivity();
					checkWASServersStatus();
					checkWASApplnEARsStatus();
				}else{
					continue; //skip current console, continue with next one
				}

				//logout from console
				open(allproperties.getProperty("WASCONSOLE"+Integer.toString(consoleIndex+1)+"LOGOUTURL"));
				Thread.sleep(5000);
				consoleIndex++;
			}
		}
		catch (InterruptedException e) {
			e.printStackTrace();
			try {
				bw.write(e.getMessage());
			} catch (IOException e1) {
				e1.printStackTrace();
			}
		}
		catch(Exception e){
			try {
				bw.write(e.getMessage());
			} catch (IOException e1) {
				e1.printStackTrace();
			}
		}
	}

	//Check WAS Application EARs status
	private static void checkWASApplnEARsStatus() {
		int i=0;
		String strEARStatus,temp,strApplnEARName;
		try{
			//go to WebSphere Enterprise Applications page
			open(allproperties.getProperty("WASCONSOLE"+Integer.toString(consoleIndex+1)+"APPLNEARSSTATUSURL"));
			Thread.sleep(3000);
			$(By.id("com_ibm_ws_prefsTableImg")).shouldBe(visible);
			//Set display preferences
			//maximize Preferences
			$(By.id("com_ibm_ws_prefsTableImg")).click();  
			//set display rows count to 50
			$(By.name("text1")).setValue("50");
			$(By.id("checkbox2")).setSelected(false);
			//Show items group level 'ALL Scopes'
			$(By.name("list3")).selectOption(0); 
			$(By.name("submit2")).click();
			Thread.sleep(2000);
			//minimize Preferences
			$(By.id("com_ibm_ws_prefsTableImg")).click(); 
			Thread.sleep(1000);

			//get web elements - application ear name & application status
			List<SelenideElement> elementsList = $(".framing-table").findAll(By.className("collection-table-text"));
			List<SelenideElement> earsStatusList = ($(".framing-table").findAll(By.tagName("img")));
			LinkedList<String> applnEARNamesList = new LinkedList<String>();
			LinkedList<String> applnEARsStatusList = new LinkedList<String>();

			//Extract Application EAR Names
			for(i=0;i<elementsList.size();i++){
				temp=(elementsList.get(i)).toString();
				if(temp.contains("headers=\"name\"")){
					str = new StringTokenizer(temp, "<>");
					str.nextToken();
					strApplnEARName=str.nextToken();
					applnEARNamesList.add(strApplnEARName);
				}
			}
			//Extract Application EARs status
			for(SelenideElement e:earsStatusList) {
				strEARStatus = e.toString();
				if(strEARStatus.contains("name=")){
					strEARStatus = (e.hover()).toString();
					str = new StringTokenizer(strEARStatus,"\"");
					str.nextToken();
					temp = str.nextToken();
					applnEARsStatusList.add(temp);
				}
			}
			//System.out.println(applnEARNamesList);
			//System.out.println(applnEARsStatusList);

			//write server status details to excel
			columnCount = 0;
			row = sheet[sheetIndex].createRow(++rowCount);
			cell = row.createCell(++columnCount);
			cell.setCellValue("Application Name");
			cell.setCellStyle(cellStyle);
			cell = row.createCell(++columnCount);
			cell.setCellValue("Application Status");
			cell.setCellStyle(cellStyle);
			for(i=0;i<applnEARNamesList.size();i++){
				columnCount = 0;
				row = sheet[sheetIndex].createRow(++rowCount);
				cell = row.createCell(++columnCount);
				cell.setCellValue(applnEARNamesList.get(i));
				cell = row.createCell(++columnCount);
				cell.setCellValue(applnEARsStatusList.get(i));
			}

		}
		catch(Exception e){
			try {
				bw.write(e.getMessage());
			} catch (IOException e1) {
				e1.printStackTrace();
			}
			e.printStackTrace();
		}
		//blank row after WAS EARs status
		row = sheet[sheetIndex].createRow(++rowCount); 

	}

	//Check application servers status
	private static void checkWASServersStatus() {
		int i=0;
		String strServerStatus=null,temp=null,strServerName=null,strServerHostname=null;
		try{
			//go to Application servers page
			open(allproperties.getProperty("WASCONSOLE"+Integer.toString(consoleIndex+1)+"SERVERSSTATUSURL"));
			Thread.sleep(3000);
			$(By.id("com_ibm_ws_prefsTableImg")).shouldBe(visible);
			//Set display preferences
			//set display rows count to 50
			$(By.id("com_ibm_ws_prefsTableImg")).click();  //maximize Preferences
			$(By.name("text1")).setValue("50");
			$(By.id("checkbox2")).setSelected(false); 
			$(By.name("list3")).selectOption(0); //Show items group level 'ALL Scopes'
			$(By.id("checkbox4")).setSelected(true); 
			$(By.id("checkbox5")).setSelected(false); 
			$(By.id("checkbox6")).setSelected(false); 
			$(By.id("checkbox7")).setSelected(false); 
			Thread.sleep(3000);
			$(By.name("submit2")).click();
			Thread.sleep(2000);
			$(By.id("com_ibm_ws_prefsTableImg")).click(); //minimize Preferences
			Thread.sleep(3000);

			//SelenideElement se = $(By.class("table-totals"));
			if($(".table-totals").find(By.name("table-totals")).exists()){
				SelenideElement se = $(".table-totals").find(By.name("table-totals"));
				//System.out.println(se.toString());
			}
			//get web elements - servers name & hostname
			List<SelenideElement> elementsList = $(".framing-table").findAll(By.className("collection-table-text"));
			LinkedList<String> serverNamesList = new LinkedList<String>();
			LinkedList<String> serverHostnamesList = new LinkedList<String>();
			//System.out.println(elementsList);
			for(int index=0;index<elementsList.size();index++){
				temp = (elementsList.get(index)).toString();
				if(temp.contains("headers=\"name\"")){
					str = new StringTokenizer(temp,"<>");
					str.nextToken();
					strServerName = str.nextToken();
					serverNamesList.add(strServerName);	
					index+=2;
					temp = (elementsList.get(index)).toString();
				}
				if(temp.contains("headers=\"hostName\"")){
					str = new StringTokenizer(temp,"<>");
					str.nextToken();
					strServerHostname = str.nextToken();
					serverHostnamesList.add(strServerHostname);	
					index+=3; 
				}
			}

			//get web element - servers status
			List<SelenideElement> serversStatusList = $(".framing-table").findAll(By.name("statusIcon"));
			LinkedList<String> finalServersStatusList = new LinkedList<String>();

			for(SelenideElement e:serversStatusList) {
				strServerStatus = (e.hover()).toString();
				str = new StringTokenizer(strServerStatus,"\"");
				str.nextToken();
				strServerStatus = str.nextToken();
				finalServersStatusList.add(strServerStatus);
			}
			//System.out.println(finalServersStatusList);

			//write server status details to excel
			columnCount = 0;
			row = sheet[sheetIndex].createRow(++rowCount);
			cell = row.createCell(++columnCount);
			cell.setCellValue("Server Name");
			cell.setCellStyle(cellStyle);
			cell = row.createCell(++columnCount);
			cell.setCellValue("Server Hostname");
			cell.setCellStyle(cellStyle);
			cell = row.createCell(++columnCount);
			cell.setCellValue("Server Status");
			cell.setCellStyle(cellStyle);
			for(i=0;i<finalServersStatusList.size();i++){
				columnCount = 0;
				row = sheet[sheetIndex].createRow(++rowCount);
				cell = row.createCell(++columnCount);
				cell.setCellValue(serverNamesList.get(i));
				cell = row.createCell(++columnCount);
				cell.setCellValue(serverHostnamesList.get(i));
				cell = row.createCell(++columnCount);
				cell.setCellValue(finalServersStatusList.get(i));
			}
		}
		catch(Exception e){
			try {
				bw.write(e.getMessage());
			} catch (IOException e1) {
				e1.printStackTrace();
			}
		}
		//blank row after was servers status
		row = sheet[sheetIndex].createRow(++rowCount);
	}

	//Login to WAS Console
	private static boolean loginToWASConsole() {
		boolean isLoginSuccess=true;
		try{
			String strCurPageURL;
			//Goto console login page
			open(allproperties.getProperty("WASCONSOLE"+Integer.toString(consoleIndex+1)+"HOMEURL"));
			cell = row.createCell(++columnCount);
			cell.setCellValue(allproperties.getProperty("WASCONSOLE"+Integer.toString(consoleIndex+1)+"NAME"));
			cell.setCellStyle(cellStyle);
			cell = row.createCell(++columnCount);
			cell.setCellValue(allproperties.getProperty("WASCONSOLE"+Integer.toString(consoleIndex+1)+"HOMEURL"));
			row = sheet[sheetIndex].createRow(++rowCount); //put an empty row

			//System.out.println("Title1 : "+title());
			$(By.name("j_username")).shouldBe(visible);
			Thread.sleep(1000);
			$(By.name("j_username")).setValue(allproperties.getProperty("WASCONSOLE"+Integer.toString(consoleIndex+1)+"USERNAME"));
			$(By.name("j_password")).setValue(allproperties.getProperty("WASCONSOLE"+Integer.toString(consoleIndex+1)+"PASSWORD"));
			$(By.name("action")).click();
			Thread.sleep(3000);
			//check login is successful or not?
			strCurPageURL = (com.codeborne.selenide.WebDriverRunner.url()).trim();
			if(strCurPageURL.endsWith("securelogon.do")){
				//login success
			}else if(strCurPageURL.endsWith("login.do?action=secure")){
				//already somebody logged in - logout from previous session and continue now
				if($(By.name("submit")).exists()) {
					$(By.name("submit")).click();
				}
				Thread.sleep(3000);
			}else{
				//login failed - log the trace
				isLoginSuccess=false;
				columnCount = 0;
				row = sheet[sheetIndex].createRow(++rowCount);
				cell = row.createCell(++columnCount);
				cell.setCellValue("Login failed!! We're unable to connect to the console, please check immediatly.");
				consoleIndex++;
			}
		}
		catch(InterruptedException ie){
			try {
				bw.write(ie.getMessage());
			} catch (IOException e1) {
				e1.printStackTrace();
			}
		}
		return isLoginSuccess;
	}

	//Was Data sources check
	private static void checkWASDataSourcesConnectivity() {
		String strStatusMsg=null,strTestMsg=null;
		
		if((allproperties.getProperty("WASCONSOLE"+Integer.toString(consoleIndex+1)+"DATASOURCEURL")).contains("10.64.122.75:9043")){
			return; // for TFIM console, there're no data sources
		}
		try {
			//extract IDs of check boxes
			String scopeElement,checkBoxElement,prevCheckBox=null;

			//goto data sources page
			open(allproperties.getProperty("WASCONSOLE"+Integer.toString(consoleIndex+1)+"DATASOURCEURL"));
			Thread.sleep(2000);

			//display all data sources - for this set scope to 'All scopes'
			$(By.id("currentScope")).selectOption(0);

			//set display rows count to 50
			$(By.id("com_ibm_ws_prefsTableImg")).click();  //maximize Preferences
			$(By.name("text1")).setValue("50");
			$(By.name("submit2")).click();
			Thread.sleep(1000);
			$(By.id("com_ibm_ws_prefsTableImg")).click(); //minimize Preferences

			List<SelenideElement> CheckBoxList = $(".framing-table").findAll(By.name("selectedObjectIds"));
			List<SelenideElement> ScopesList = $(".framing-table").findAll(By.className("collection-table-text"));

			Set<String> checkBoxIDs = new LinkedHashSet<String>();
			LinkedList<String> scopeMsgs = new LinkedList<String>();
			LinkedList<String> dataSourceNames = new LinkedList<String>();

			//Extract and store Data source names & their Scopes
			for(int i=0;i<ScopesList.size();i++) {
				scopeElement = (ScopesList.get(i)).toString();
				if(scopeElement.contains("headers=\"name\"")){
					str = new StringTokenizer(scopeElement,"><");
					str.nextToken();
					scopeElement = str.nextToken();
					dataSourceNames.add(scopeElement);
					i+=2; //skip unnecessary elements, go to scope
				}
				scopeElement = (ScopesList.get(i)).toString();
				if(scopeElement.contains("headers=\"contextId\"")){
					str = new StringTokenizer(scopeElement,"><");
					str.nextToken();
					scopeElement = str.nextToken();
					scopeMsgs.add(scopeElement);
					i+=3; //skip unnecessary elements, go to element prior name
				}
			}

			//Extract data sources check box IDs
			for(SelenideElement se:CheckBoxList){
				checkBoxElement = se.toString();
				str = new StringTokenizer(checkBoxElement,"\"");
				str.nextToken();
				checkBoxElement = (str.nextToken()).trim();
				checkBoxIDs.add(checkBoxElement);
			}

			//write header for data sources test result
			columnCount = 0;
			row = sheet[sheetIndex].createRow(++rowCount);
			cell = row.createCell(++columnCount);
			cell.setCellValue("Datasource Name");
			cell.setCellStyle(cellStyle);
			cell = row.createCell(++columnCount);
			cell.setCellValue("Scope");
			cell.setCellStyle(cellStyle);
			cell = row.createCell(++columnCount);
			cell.setCellValue("Test connectivity?");
			cell.setCellStyle(cellStyle);
			cell = row.createCell(++columnCount);
			cell.setCellValue("Comments");
			cell.setCellStyle(cellStyle);

			int dsColumnIndex=0;
			//check connectivity for all data sources one after another and write to result excel
			for(String curCheckBox:checkBoxIDs){
				//skip these data sources - 'UPCIMDS_CH2.0' - Orion console & 'Default Datasource' - all consoles
				if(((dataSourceNames.get(dsColumnIndex)).contains("UPCIMDS_CH2.0"))||((dataSourceNames.get(dsColumnIndex)).contains("Default Datasource"))){ 
					dsColumnIndex++;
				}else{
					columnCount = 0;
					if(null!=prevCheckBox) { $(By.id(prevCheckBox)).setSelected(false); }
					$(By.id(curCheckBox)).setSelected(true);
					Thread.sleep(1000);
					$(By.name("button.testConnection")).click();
					Thread.sleep(3000);
					if($(By.id("com_ibm_ws_inlineMessagesImg")).exists())$(By.id("com_ibm_ws_inlineMessagesImg")).shouldBe(visible); //status msg img
					$(By.id(curCheckBox)).shouldNotBe(selected);

					//Extract status message of test connectivity
					List<SelenideElement> testStatusMsgs =null;
					if($(By.id("com_ibm_ws_inlineMessages")).exists()) { testStatusMsgs = $(By.id("com_ibm_ws_inlineMessages")).findAll(By.className("validation-warn-info")); }
					strStatusMsg= new String();
					//for every successful connectivity, we may get more than one connectivity status message
					for(SelenideElement se:testStatusMsgs){
						strTestMsg = se.toString();
						str = new StringTokenizer(strTestMsg,"><");
						str.nextToken();
						strTestMsg = str.nextToken();
						strStatusMsg = strStatusMsg.concat(strTestMsg);
					}
					//create a row for current data source test result
					row = sheet[sheetIndex].createRow(++rowCount);
					cell = row.createCell(++columnCount);
					cell.setCellValue(dataSourceNames.get(dsColumnIndex)); //data source name
					cell = row.createCell(++columnCount);
					cell.setCellValue(scopeMsgs.get(dsColumnIndex)); //it's scope
					dsColumnIndex++;

					//Write connectivity status to output file
					if($(By.className("validation-warn-info")).exists()){
						//strStatusMsg
						//System.out.println(" -- 1 :"+strStatusMsg);
						cell = row.createCell(++columnCount);
						cell.setCellValue("Success");
						cell = row.createCell(++columnCount);
						cell.setCellValue(strStatusMsg);
					}
					else if($(By.className("validation-error")).exists()){
						strStatusMsg=$(By.className("validation-error")).toString();
						str = new StringTokenizer(strStatusMsg,"><");
						str.nextToken();
						strStatusMsg = str.nextToken();
						//System.out.println(" -- 2 :"+strStatusMsg);
						cell = row.createCell(++columnCount);
						cell.setCellValue("Failed");
						cell = row.createCell(++columnCount);
						cell.setCellValue(strStatusMsg);
					}

					prevCheckBox=curCheckBox;
					//for every 5 data sources, just wait for 3 seconds
					if(dsColumnIndex%5==0) { 
						Thread.sleep(3000);
					}
				}  
			}
		}
		catch(InterruptedException ie){
			try {
				bw.write(ie.getMessage());
			} catch (IOException e1) {
				e1.printStackTrace();
			}
		}
		//blank row after was data sources status
		row = sheet[sheetIndex].createRow(++rowCount);
	}
}
