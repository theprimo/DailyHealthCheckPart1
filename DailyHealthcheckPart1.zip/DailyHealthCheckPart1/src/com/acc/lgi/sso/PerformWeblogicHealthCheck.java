package com.acc.lgi.sso;

import static com.codeborne.selenide.Condition.visible;
import static com.codeborne.selenide.Selenide.$;
import static com.codeborne.selenide.Selenide.open;

import java.io.IOException;
import java.util.List;
import java.util.StringTokenizer;

import org.openqa.selenium.By;

import com.codeborne.selenide.SelenideElement;

public class PerformWeblogicHealthCheck extends PerformHealthCheckPart1 {
	static String WEBLOGICHOMEURL;
	static String WEBLOGICDATASOURCEURL;
	static String WEBLOGICSERVERSSTATUSURL;
	static String WEBLOGICAPPLNEARSSTATUSURL;
	//Check Weblogic console & servers health
	public static void checkWeblogicHealthCheck(){
		try{
			consoleIndex=0;
			rowCount=0;
			//noOfWeblogicConsoles=1;
			//Go through all Weblogic consoles and perform the checks
			//while(consoleIndex < noOfWeblogicConsoles) {
			for(consoleIndex=0;consoleIndex < noOfWeblogicConsoles;consoleIndex++){
				WEBLOGICHOMEURL=allproperties.getProperty("WLCONSOLE"+Integer.toString(consoleIndex+1)+"HOMEURL");
				WEBLOGICDATASOURCEURL=WEBLOGICHOMEURL+"console.portal?_nfpb=true&_pageLabel=GlobalJDBCDataSourceTablePage";
				WEBLOGICSERVERSSTATUSURL=WEBLOGICHOMEURL+"console.portal?_nfpb=true&_pageLabel=CoreServerServerTablePage";
				WEBLOGICAPPLNEARSSTATUSURL=WEBLOGICHOMEURL+"console.portal?_nfpb=true&_pageLabel=AppDeploymentsControlPage";
				row = sheet[sheetIndex].createRow(++rowCount);
				columnCount = 0;
				if(loginToWeblogicConsole()){
					//go further
					checkWeblogicDataSourcesConnectivity();
					checkWeblogicServersStatus();
					checkWeblogicApplnEARsStatus();
					//logout from console
					$(By.linkText("Log Out")).click();
					Thread.sleep(5000);
				}else{
					//do nothing
				}				
			}
		}
		catch (InterruptedException e) {
			e.printStackTrace();
			try {
				bw.write(e.toString());
			} catch (IOException e1) {
				e1.printStackTrace();
			}
		}
		catch(Exception e){
			try {
				bw.write(e.getMessage());
			} catch (IOException e1) {
				e1.printStackTrace();
			}
		}
	}

	//Check Weblogic Application EARs status
	private static void checkWeblogicApplnEARsStatus() {
		int i=0,noOfEARs=0,intEARsCounter=0;
		String strEARName=null,strEARsCounter=null,strHealthCellID,strStateCellID,strEARCellID,strEARState,strEARHealth;
		try{
			//go to Enterprise Application EARs deployments page
			open(WEBLOGICAPPLNEARSSTATUSURL);
			Thread.sleep(3000);
			//Customize display preferences - set to 25
			$(By.partialLinkText("Customize this table")).shouldBe(visible);
			$(By.partialLinkText("Customize this table")).click();
			$(By.name("AppDeploymentsControlPortlettablePreferences.rowsPerPage")).selectOption(1);
			List<SelenideElement> prefCustList = $(By.className("buttonRow")).findAll(By.tagName("input"));
			Thread.sleep(2000);
			//Apply preferences 
			prefCustList.get(0).click(); 
			Thread.sleep(3000);
			//just to wait until page gets loaded
			$(By.partialLinkText("Customize this table")).shouldBe(visible);
			strEARsCounter=(($(By.className("tablenavigation")).getText()).toString());
			str = new StringTokenizer(strEARsCounter, " ");
			str.nextToken();
			str.nextToken();
			str.nextToken();
			strEARsCounter=(str.nextToken()).trim();
			noOfEARs = Integer.parseInt(strEARsCounter);

			//Write Appln EARs status header to excel
			columnCount = 0;
			row = sheet[sheetIndex].createRow(++rowCount);
			cell = row.createCell(++columnCount);
			cell.setCellValue("EAR Name");
			cell.setCellStyle(cellStyle);
			cell = row.createCell(++columnCount);
			cell.setCellValue("EAR State");
			cell.setCellStyle(cellStyle);
			cell = row.createCell(++columnCount);
			cell.setCellValue("EAR Health");
			cell.setCellStyle(cellStyle);

			//Access EARs one by one by their IDs
			for(intEARsCounter=1;intEARsCounter<=noOfEARs;intEARsCounter++){
				columnCount=0;
				//if(intEARsCounter>=4) break;
				strEARsCounter=Integer.toString(intEARsCounter);				
				strEARCellID = "name" + strEARsCounter;
				strStateCellID = "state" + strEARsCounter;
				strHealthCellID = "health" + strEARsCounter;
				strEARName = $(By.id(strEARCellID)).getText();
				strEARState = $(By.id(strStateCellID)).getText();
				strEARHealth = $(By.id(strHealthCellID)).getText();
				//System.out.println("EAR : "+strEARName);
				row = sheet[sheetIndex].createRow(++rowCount);
				cell = row.createCell(++columnCount);
				cell.setCellValue(strEARName);
				cell = row.createCell(++columnCount);
				cell.setCellValue(strEARState);
				cell = row.createCell(++columnCount);
				cell.setCellValue(strEARHealth);
			}
		}
		catch(Exception e){
			try {
				bw.write(e.getMessage());
			} catch (IOException e1) {
				e1.printStackTrace();
			}
		}
		//blank row after weblogic Application EARs status
		row = sheet[sheetIndex].createRow(++rowCount); 
	}

	private static void checkWeblogicServersStatus() {
		int i=0,noOfServers=0,intServersCounter=0;
		String strServerName=null,strServersCounter=null,strHealthCellID,strStateCellID,strServerCellID,strServerState,strServerHealth;
		try{
			//go to Application servers page
			open(WEBLOGICSERVERSSTATUSURL);
			Thread.sleep(3000);
			//Customize display preferences - set to 25
			$(By.partialLinkText("Customize this table")).shouldBe(visible);
			$(By.partialLinkText("Customize this table")).click();
			$(By.name("CoreServerServerTablePortlettablePreferences.rowsPerPage")).selectOption(1);
			List<SelenideElement> prefCustList = $(By.className("buttonRow")).findAll(By.tagName("input"));
			Thread.sleep(2000);
			//Apply preferences 
			prefCustList.get(0).click(); 
			Thread.sleep(4000);
			//Refresh status icon should be visible - just to wait until page gets loaded
			$(By.id("refreshIcondefaultRegion")).shouldBe(visible);
			strServersCounter=(($(By.className("tablenavigation")).getText()).toString());
			str = new StringTokenizer(strServersCounter, " ");
			str.nextToken();
			str.nextToken();
			str.nextToken();
			strServersCounter=(str.nextToken()).trim();
			noOfServers = Integer.parseInt(strServersCounter);

			//Write Data sources status header to excel
			columnCount = 0;
			row = sheet[sheetIndex].createRow(++rowCount);
			cell = row.createCell(++columnCount);
			cell.setCellValue("Server Name");
			cell.setCellStyle(cellStyle);
			cell = row.createCell(++columnCount);
			cell.setCellValue("Server State");
			cell.setCellStyle(cellStyle);
			cell = row.createCell(++columnCount);
			cell.setCellValue("Server Health");
			cell.setCellStyle(cellStyle);

			//Access servers one by one by their IDs
			for(intServersCounter=1;intServersCounter<=noOfServers;intServersCounter++){
				columnCount=0;
				//if(intServersCounter>=4) break;
				strServersCounter=Integer.toString(intServersCounter);				
				strServerCellID = "name" + strServersCounter;
				strStateCellID = "state" + strServersCounter;
				strHealthCellID = "health" + strServersCounter;
				strServerName = $(By.id(strServerCellID)).find(By.tagName("a")).getText();
				strServerState = $(By.id(strStateCellID)).getText();
				strServerHealth = $(By.id(strHealthCellID)).getText();
				row = sheet[sheetIndex].createRow(++rowCount);
				cell = row.createCell(++columnCount);
				cell.setCellValue(strServerName);
				cell = row.createCell(++columnCount);
				cell.setCellValue(strServerState);
				cell = row.createCell(++columnCount);
				cell.setCellValue(strServerHealth);
			}
		}
		catch(Exception e){
			try {
				bw.write(e.getMessage());
			} catch (IOException e1) {
				e1.printStackTrace();
			}
		}
		//blank row after weblogic servers status
		row = sheet[sheetIndex].createRow(++rowCount); 
	}

	//Check Weblogic console data sources connectivity
	private static void checkWeblogicDataSourcesConnectivity() {
		int noOfDataSources=0,intDSCounter=0,intServerCounter=0;
		String strDSName=null,strDSCountString=null,strDSCounter=null,strDSCellID=null,strStatusMsg=null,strDSServerID=null,strDSServerName=null;
		try {
			//goto data sources page
			open(WEBLOGICDATASOURCEURL);
			Thread.sleep(3000);
			//Customize data source results
			$(By.partialLinkText("Customize this table")).shouldBe(visible);
			$(By.partialLinkText("Customize this table")).click();
			$(By.name("GlobalJDBCDataSourceTablePortlettablePreferences.rowsPerPage")).selectOption(2);
			List<SelenideElement> prefCustList = $(By.className("buttonRow")).findAll(By.tagName("input"));
			Thread.sleep(2000);
			//Apply preferences 
			prefCustList.get(0).click(); 
			Thread.sleep(2000);
			$(By.partialLinkText("Customize this table")).shouldBe(visible);

			strDSCountString=(($(By.className("tablenavigation")).getText()).toString());
			str = new StringTokenizer(strDSCountString, " ");
			str.nextToken();
			str.nextToken();
			str.nextToken();
			strDSCounter=(str.nextToken()).trim();
			noOfDataSources = Integer.parseInt(strDSCounter);

			//Write Data sources status header to excel
			columnCount = 0;
			row = sheet[sheetIndex].createRow(++rowCount);
			cell = row.createCell(++columnCount);
			cell.setCellValue("Data source Name");
			cell.setCellStyle(cellStyle);
			cell = row.createCell(++columnCount);
			cell.setCellValue("Server Name");
			cell.setCellStyle(cellStyle);
			cell = row.createCell(++columnCount);
			cell.setCellValue("Test connectivity status");
			cell.setCellStyle(cellStyle);

			//Access Data sources one by one by their IDs
			for(intDSCounter=1;intDSCounter<=noOfDataSources;intDSCounter++){
				//if(intDSCounter>=11) break; //testing
				strDSCounter=Integer.toString(intDSCounter);
				strDSCellID = "Name" + strDSCounter;
				//open data source
				strDSName = $(By.id(strDSCellID)).find(By.tagName("a")).getText();
				$(By.id(strDSCellID)).find(By.tagName("a")).click();
				Thread.sleep(2000);
				$(By.name("Save")).shouldBe(visible);
				//goto Monitoring tab
				$(By.partialLinkText("Monitoring")).click();
				Thread.sleep(2000);
				$(By.partialLinkText("Customize this table")).shouldBe(visible);
				//goto Testing sub tab
				if(($(By.partialLinkText("Testing")).exists())&&($(By.partialLinkText("Testing")).isEnabled())){
					$(By.partialLinkText("Testing")).click();
					Thread.sleep(2000);
					$(By.partialLinkText("Customize this table")).shouldBe(visible);
				}

				//Go thru all servers and test the data source connectivity
				//get list of servers (radio buttons) by their IDs - ID & Name is same for all
				List<SelenideElement> dsServersList = ($(By.name("genericTableForm"))).findAll(By.id("JdbcDatasourcesJDBCDataSourceMonitorTestingPortletchosenContents"));
				intServerCounter=1;
				for(SelenideElement se:dsServersList){
					//select data source radio button
					se.click();
					//Test data source - Test Data Source
					if($(By.name("Testdatasource")).exists()){
						$(By.name("Testdatasource")).shouldBe(visible);
						$(By.name("Testdatasource")).click();
					}else if($(By.name("Test Data Source")).exists()){
						$(By.name("Test Data Source")).shouldBe(visible);
						$(By.name("Test Data Source")).click();
					}

					Thread.sleep(2000);
					//check test status
					$(By.className("message")).shouldBe(visible);
					strStatusMsg = ($(By.className("message")).getText()).trim();
					//get Data source server name
					strDSServerID="server"+ Integer.toString(intServerCounter);
					strDSServerName = $(By.id(strDSServerID)).getText();
					columnCount=0;
					//write status to excel
					row = sheet[sheetIndex].createRow(++rowCount);
					cell = row.createCell(++columnCount);
					cell.setCellValue(strDSName);
					cell = row.createCell(++columnCount);
					cell.setCellValue(strDSServerName);
					cell = row.createCell(++columnCount);
					if(strStatusMsg.endsWith("was successful.")){
						cell.setCellValue("Success");						
					}else{
						cell.setCellValue("Failed");
					}
					intServerCounter++;
				}
				//Once servers data source test connectivity is over for current data source, then again go to data sources list page
				open(WEBLOGICDATASOURCEURL);
				Thread.sleep(2000);
			}
			Thread.sleep(2000);

		}catch (InterruptedException e) {
			try {
				bw.write(e.getMessage());
			} catch (IOException e1) {
				e1.printStackTrace();
			}
		}
		catch(Exception e){
			try {
				bw.write(e.getMessage());
			} catch (IOException e1) {
				e1.printStackTrace();
			}
		}
		//blank row after weblogic data sources check
		row = sheet[sheetIndex].createRow(++rowCount); 
	}

	//Login to Weblogic console
	private static boolean loginToWeblogicConsole() {
		boolean isLoginSuccess=true;
		try{
			String strCurPageURL;
			//Goto console login page
			open(WEBLOGICHOMEURL);
			Thread.sleep(2000);
			cell = row.createCell(++columnCount);
			cell.setCellValue(allproperties.getProperty("WLCONSOLE"+Integer.toString(consoleIndex+1)+"NAME"));
			cell.setCellStyle(cellStyle);
			cell = row.createCell(++columnCount);
			cell.setCellValue(WEBLOGICHOMEURL);
			row = sheet[sheetIndex].createRow(++rowCount); //put an empty row
			//Check if session is already logged in
			strCurPageURL = (com.codeborne.selenide.WebDriverRunner.url()).trim();
			if(strCurPageURL.endsWith("_pageLabel=HomePage1")){
				//fine, already some one logged in
				if($(By.id("toolbarSearchInput")).exists()) { $(By.id("toolbarSearchInput")).shouldBe(visible); }
				Thread.sleep(2000);
			}else if(strCurPageURL.endsWith("LoginForm.jsp")){  
				$(By.name("j_username")).shouldBe(visible);
				Thread.sleep(1000);
				$(By.name("j_username")).setValue(allproperties.getProperty("WLCONSOLE"+Integer.toString(consoleIndex+1)+"USERNAME"));
				$(By.name("j_password")).setValue(allproperties.getProperty("WLCONSOLE"+Integer.toString(consoleIndex+1)+"PASSWORD"));
				$(By.className("formButton")).click();
				Thread.sleep(3000);
				//check login is successful or not?
				strCurPageURL = (com.codeborne.selenide.WebDriverRunner.url()).trim();
				if(strCurPageURL.endsWith("_pageLabel=HomePage1")){
					if($(By.id("toolbarSearchInput")).exists()) { $(By.id("toolbarSearchInput")).shouldBe(visible); }
				}else{
					//login failed - log the trace
					isLoginSuccess=false;
					columnCount = 0;
					row = sheet[sheetIndex].createRow(++rowCount);
					cell = row.createCell(++columnCount);
					cell.setCellValue("Login failed!! We're unable to connect to the console, please check immediatly.");
				}
			}			
		}
		catch(InterruptedException ie){
			try {
				bw.write(ie.getMessage());
			} catch (IOException e1) {
				e1.printStackTrace();
			}
		}
		return isLoginSuccess;
	}
}
