package com.acc.lgi.sso;

import java.awt.List;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.io.PrintStream;
import java.util.ArrayList;
import java.util.StringTokenizer;

import com.jcraft.jsch.Channel;
import com.jcraft.jsch.ChannelExec;
import com.jcraft.jsch.ChannelShell;
import com.jcraft.jsch.JSch;
import com.jcraft.jsch.JSchException;
import com.jcraft.jsch.Session;

public class TestSSH {

	public static void main(String[] args) {
		String command = "cd /opt/ibm/ldap/V6.3.1/bin;./ibmdirctl -D cn=root -w '17,|uZnpdIC\\MzAK,.MN' status;";
		//String command="ssh 172.28.48.176";
		runNexusCommandViaSSH("skatta","Aurora@123","10.64.117.15",command);
	}

	private static void runNexusCommandViaSSH(String sshuser, String sshpass, String sshhost, String command){
		String serverStatus=null;
		Channel channel=null;
		Session session=null;
		String buffer=null;
		boolean check=false;
		try {
			ArrayList<String> results = new ArrayList<String>();
			java.util.Properties config = new java.util.Properties();
			config.put("StrictHostKeyChecking", "no");

			System.out.println(command);

			JSch jsch = new JSch();

			session = jsch.getSession(sshuser, sshhost, 22);

			session.setPassword(sshpass);
			session.setConfig(config);
			session.setTimeout(10000);
			session.connect();

			channel = session.openChannel("shell");

			channel.setInputStream(null);
			channel.setOutputStream(null);

			InputStream in = channel.getInputStream();
			OutputStream out = channel.getOutputStream();

			// Create a stream to hold the output
			ByteArrayOutputStream baos = new ByteArrayOutputStream();
			PrintStream ps = new PrintStream(baos);
			// IMPORTANT: Save the old System.out!
			PrintStream old = System.out;
			// Tell Java to use your special stream
			System.setOut(ps);
			// Print some output: goes to your special stream
			//System.out.println("Foofoofoo!");

			((ChannelShell)channel).setPtyType("vt102");
			channel.connect();

			byte[] tmp=new byte[1024];

			out.write((command).getBytes());
			out.write(("\n").getBytes());
			out.write(("Aurora@123").getBytes());
			out.write(("\n").getBytes());
			out.write(("free -m;exit").getBytes());
			out.write(("\n").getBytes());
			out.flush();

			while (true) {  
				while (in.available() > 0) {
					int i = in.read(tmp, 0, 1024);
					if (i < 0) {
						break;
					}
					buffer = new String(tmp, 0, i);
					System.out.println(buffer);
					/*
					if(null==buffer){						
						if(buffer.contains("Directory server is running.")){
							check=true;
						}else{
							check=false;
						}
					}/*
					if(buffer.contains("REMOTE JSH COMMAND FINISHED")){
						System.out.println("[debug] breaking at finished");
						break;
					}*/
				}
				if (channel.isClosed()) {
					//System.out.println("[debug] breaking at isClosed");
					in.close();
					break;
				}else{
					in.close();
					break;
				}
			}
			// Put things back
			System.out.flush();
			System.setOut(old);
			// Show what happened
			System.out.println("Here: " + baos.toString());
		} catch (JSchException e) {
		} catch (IOException e) {
			e.printStackTrace();
		} catch(Exception e){
		}
		finally{
			//check the unix box is up or not ?
			if(null==serverStatus){
			}
			if(check==true){
				System.out.println("Yes");
			}else{
				System.out.println("No");
			}
			if(null!=channel)channel.disconnect();
			if(null!=session)session.disconnect();
		}
		if(check==true){
			System.out.println("Yes");
		}else{
			System.out.println("No");
		}
		System.out.println("--Done-");
	}
}
