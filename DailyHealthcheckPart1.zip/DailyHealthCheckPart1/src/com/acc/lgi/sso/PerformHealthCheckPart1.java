package com.acc.lgi.sso;


import com.google.common.base.Predicate;

import java.util.ArrayList;
import java.util.LinkedHashSet;
import java.util.LinkedList;
import java.util.List;
import java.util.Properties;
import java.util.Set;
import java.util.StringTokenizer;

import javax.xml.transform.Source;

import java.io.*;

import org.apache.poi.ss.formula.functions.Index;
//import org.apache.poi.xssf.usermodel.*;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.CellStyle;
import org.apache.poi.ss.usermodel.Font;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

import static com.codeborne.selenide.Condition.*;
import static com.codeborne.selenide.Selectors.*;
import static com.codeborne.selenide.Selenide.*;
import static com.codeborne.selenide.Selenide.$;
import static com.codeborne.selenide.WebDriverRunner.CHROME;

import com.codeborne.selenide.commands.Find;
import com.codeborne.selenide.commands.FollowLink;
import com.jcraft.jsch.Channel;
import com.jcraft.jsch.ChannelExec;
import com.jcraft.jsch.ChannelShell;
import com.jcraft.jsch.JSch;
import com.jcraft.jsch.JSchException;
import com.jcraft.jsch.Session;
import com.codeborne.selenide.ElementsCollection;
import com.codeborne.selenide.Selenide;
import com.codeborne.selenide.SelenideElement;
import com.codeborne.selenide.SelenideTargetLocator;

import org.junit.Test;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.ie.InternetExplorerDriver;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.WebDriver.TargetLocator;

import com.thoughtworks.selenium.webdriven.commands.Open;
import com.codeborne.selenide.WebDriverRunner.*;
import com.acc.lgi.sso.PerformWASHealthCheck;
import com.acc.lgi.sso.PerformWeblogicHealthCheck;
import com.acc.lgi.sso.PerformMemoryStatusCheck;

public class PerformHealthCheckPart1 {
	static File logFile;
	static String logFilePath;
	static FileWriter fw;
	static BufferedWriter bw;

	static Properties allproperties=null;

	static XSSFSheet sheet[]={null,null,null,null,null,null};
	static XSSFWorkbook workbook;
	static CellStyle cellStyle;
	static Row row;
	static Cell cell;
	static int noOfSheets;
	static int noOfServerTypes;
	static int consoleIndex;
	static int rowCount;
	static int columnCount;
	static int sheetIndex;
	static StringTokenizer str;
	static int noOfWASConsoles;
	static int noOfWeblogicConsoles;
	static int noOfWASServers;
	static int noOfLDAPServers;
	static int noOfNLAHServers;
	static int noOfNLCareServers;
	static int noOfNLSSOSherpaServers;
	static int noOfSKAHServers;
	static int noOfSKSSOServers;
	static int noOfIESSOServers;
	static int noOfHUIDCheckServers;
	static int noOfTMNGXATServers;
	static int noOfHYSTRIXCEEServers;
	static String unixUsername;
	static String unixPassword;
	static String unixMemCheckCmd;

	static final int NOOFHZGOAPPLICATIONS=8;
	
	public static void main(String args[]){
		try{
			//PerformHealthCheckPart1 obj = new PerformHealthCheckPart1();
			PerformHealthCheckPart1.initialize();
			PerformHealthCheckPart1.performHealthCheck();		
		}catch(Exception e){
			System.out.println(e);
		}
		finally{
			try {
				//at the end write output to excel
				writeOutputToExcel();
				if(null!=bw){bw.close();}
				if(null!=fw){fw.close();}
			} catch (IOException e) {
				e.printStackTrace();
			}

		}	
	}

	private static void performHealthCheck() {
		try {
			//WAS & Weblogic - Go through all consoles and perform tests
			sheetIndex=0;
			String sheetname=null;
			while(sheetIndex<noOfSheets) {
				//write sheet name
				sheetname="SHEET"+Integer.toString(sheetIndex+1)+"NAME";
				sheet[sheetIndex] = workbook.createSheet(allproperties.getProperty(sheetname));
				//Cell style - create bold font style for each sheet 
				cellStyle = sheet[sheetIndex].getWorkbook().createCellStyle();
				Font font = sheet[sheetIndex].getWorkbook().createFont();
				font.setBold(true);
				cellStyle.setFont(font);
				open(""); //just open web browser
				//Sheet1: WAS Consoles
				if(sheetIndex==0) {
					try{
						System.out.println("[Info]: WAS check started");
						PerformWASHealthCheck.checkWASHealthCheck();
						System.out.println("[Info]: WAS check done");
					}catch(Exception e){
						try {
							bw.write(e.getMessage());
						} catch (IOException e1) {
							e1.printStackTrace();
						}
					}

				}
				//Sheet2: Weblogic consoles
				else if(sheetIndex==1) {
					try{
						System.out.println("[Info]: Weblogic check started");
						PerformWeblogicHealthCheck.checkWeblogicHealthCheck();
						System.out.println("[Info]: Weblogic check done");
					}catch(Exception e){
						try {
							bw.write(e.getMessage());
						} catch (IOException e1) {
							e1.printStackTrace();
						}
					}
					//close(); //close web browser
				}
				//Sheet3: MuyUPC IE & Horizon Go applications login status
				else if(sheetIndex==2) {
					try{
						System.out.println("[Info]: MyUPC and Horizon Go applications login status started");
						PerformMyUPCNHorizonApplnsLoginCheck.checkHorizonApplnsLoginFunctionality();
						System.out.println("[Info]: MyUPC and Horizon Go applications login status completed");
					}catch(Exception e){
						try {
							bw.write(e.getMessage());
						} catch (IOException e1) {
							e1.printStackTrace();
						}
					}
				}
				//Sheet4: Servers memory status
				else if(sheetIndex==3) {
					try{
						System.out.println("[Info]: Memory status started");
						PerformMemoryStatusCheck.checkServersMemoryStatus();
						System.out.println("[Info]: Memory status done");
					}catch(Exception e){
						try {
							bw.write(e.getMessage());
						} catch (IOException e1) {
							e1.printStackTrace();
						}
					}
				}
				sheetIndex++;
			}
		}
		catch(Exception e){
			try {
				bw.write(e.getMessage());
			} catch (IOException e1) {
				e1.printStackTrace();
			}
			System.out.println(e);
		}
	}

	//Load initial properties
	private static void initialize() {
		workbook = null;
		cellStyle = null;
		row = null;
		cell = null;
		str=null;
		consoleIndex=0;
		rowCount = 0;
		columnCount = 0;
		sheetIndex=0;

		//set default session timeout - 60s & test timeout - 60s
		System.setProperty("selenide.collectionsTimeout", "60000");
		System.setProperty("selenide.timeout", "60000");

		//set binary chromedriver path	
		try {
			File file = new File(System.getProperty("user.dir")+"\\"+ "chromedriver.exe");
			System.setProperty("webdriver.chrome.driver",file.getAbsolutePath());
		} catch (Exception e) {
			try {
				bw.write("[Error]: Chromium binary chromedriver.exe file was not found, please check!!");
				e.printStackTrace();
			} catch (IOException e1) {
				e1.printStackTrace();
			}
		}
		//set default browser to chrome
		System.setProperty("browser", CHROME);
		System.setProperty("selenide.browser",System.getProperty("browser", CHROME));

		//create log file
		logFilePath = System.getProperty("user.dir")+"\\"+ "DailyHealthCheckPart1LogFile.log";
		logFile = new File(logFilePath);

		try {
			fw = new FileWriter(logFile.getAbsoluteFile());
			bw = new BufferedWriter(fw);
		} catch (IOException e) {
			try {
				bw.write("[Error]: Unable to connect to log file ");
				e.printStackTrace();
				bw.write(e.toString());
			} catch (IOException e1) {
				e1.printStackTrace();
			}
		}

		//load properties from external config.properties file
		allproperties = new Properties();
		try {
			allproperties.load(new FileInputStream(System.getProperty("user.dir")+"\\"+"config.properties"));
		} catch (FileNotFoundException e) {
			try {
				bw.write("[ERROR]: config.properties file was not found, please check!!");
			} catch (IOException e1) {
				e1.printStackTrace();
			}
			e.printStackTrace();
			return;
		} catch (IOException e) {
			e.printStackTrace();
		}

		//initialize loaded primary values
		noOfSheets=Integer.parseInt((allproperties.getProperty("NOOFSHEETS")).trim());
		noOfWASConsoles=Integer.parseInt((allproperties.getProperty("NOOFWASCONSOLES")).trim());
		noOfWeblogicConsoles=Integer.parseInt((allproperties.getProperty("NOOFWEBLOGICCONSOLES")).trim());
		noOfServerTypes=Integer.parseInt((allproperties.getProperty("NOOFSERVERTYPES")).trim()); 
		noOfWASServers=Integer.parseInt((allproperties.getProperty("NOOFWASSERVERS")).trim());
		noOfLDAPServers=Integer.parseInt((allproperties.getProperty("NOOFLDAPSERVERS")).trim());
		noOfNLAHServers=Integer.parseInt((allproperties.getProperty("NOOFNLAHSERVERS")).trim());
		noOfNLCareServers=Integer.parseInt((allproperties.getProperty("NOOFNLCARESERVERS")).trim());
		noOfNLSSOSherpaServers=Integer.parseInt((allproperties.getProperty("NOOFNLSSOSHERPASERVERS")).trim());
		noOfSKAHServers=Integer.parseInt((allproperties.getProperty("NOOFSKAHSERVERS")).trim());
		noOfSKSSOServers=Integer.parseInt((allproperties.getProperty("NOOFSKSSOSERVERS")).trim());
		noOfIESSOServers=Integer.parseInt((allproperties.getProperty("NOOFIESSOSERVERS")).trim());
		noOfHUIDCheckServers=Integer.parseInt((allproperties.getProperty("NOOFHUIDCHECKSERVERS")).trim());
		noOfTMNGXATServers=Integer.parseInt((allproperties.getProperty("NOOFTMNGXATSERVERS")).trim());
		noOfHYSTRIXCEEServers=Integer.parseInt((allproperties.getProperty("NOOFHYSTRIXCEESERVERS")).trim());
		
		//for servers memory check
		unixUsername=(allproperties.getProperty("UNIXUSERNAME")).trim();
		unixPassword=(allproperties.getProperty("UNIXPASSWORD")).trim();
		unixMemCheckCmd=(allproperties.getProperty("UNIXMEMORYCHECKCOMMAND")).trim();
		
		//write result to excel workbook
		workbook = new XSSFWorkbook();
	}

	private static void writeOutputToExcel() {
		//at the end write contents to output excel
		File resFile = null;
		FileOutputStream outputStream = null;
		try {
			//String strFilePath = Test.class.getResource("/Files/WASDatasourceTestFile.xlsx").getPath();
			//String strFilePath = "D:\\SSO_AM\\Daily_Health_Check\\WAS_DS_Connectivity\\WASDatasourceTestFile.xlsx";
			//Create file in current working directory
			String strFilePath = System.getProperty("user.dir")+"\\"+ "DailyHealthCheckPart1.xlsx";
			resFile = new File(strFilePath);
			if(resFile.exists()){
				resFile.delete();
			}
			resFile.createNewFile();
			outputStream = new FileOutputStream(strFilePath);
			workbook.write(outputStream);
			//outputStream.flush();
			System.out.println("Test Workbook has been written successfully on disk.");
		}
		catch(IOException e){
			try {
				bw.write(e.toString());
			} catch (IOException e1) {
				e1.printStackTrace();
			}
		}
		catch(Exception e){
			try {
				bw.write("[Error]: Unable to connect to output excel file ");
				e.printStackTrace();
				bw.write(e.toString());
			} catch (IOException e1) {
				e1.printStackTrace();
			}
		}
		finally{
			if(null != outputStream){ try {
				outputStream.close();
			} catch (IOException e) {
				e.printStackTrace();
			} }
			resFile = null;
		}

	}
}
