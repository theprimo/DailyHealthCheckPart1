package com.acc.lgi.sso;

import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.CellStyle;
import org.apache.poi.ss.usermodel.Font;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;

import com.codeborne.selenide.SelenideElement;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import static com.codeborne.selenide.Condition.*;
import static com.codeborne.selenide.Selectors.*;
import static com.codeborne.selenide.Selenide.*;

public class PerformMyUPCNHorizonApplnsLoginCheck extends PerformHealthCheckPart1 {
	public static void checkHorizonApplnsLoginFunctionality(){
		try{
			checkApplnsLoginStatus();
		}
		catch(Exception e){
			try {
				bw.write(e.toString());
			} catch (IOException e1) {
				e1.printStackTrace();
			}
		}

	}

	private static void checkApplnsLoginStatus() {
		String strCurPageURL=null,strLoginURL=null,strLoginUser=null,strLoginPassword=null,strHomeURL=null,strAppName=null;
		int counter=1,appCounter=1;
		SelenideElement loginButton=null;
		List<SelenideElement> list=null;
		final String WRONGCREDSERRORMSG="[Error]: Login failed, Username or password is incorrect. Please check immediately!!";
		final String LANDINGFAILERRORMSG="[Error]: Login works, but not landing on homepage. Please check!!";
		final String LOGINFAILERRORMSG="[Error]: Login failed, Please check immediately!!";
		final String LOGINPAGEFAILERRORMSG="[Error]: Unable to open login page, Please check immediately!!";

		try{
			//Applications login status header
			columnCount = 0;
			rowCount=0;
			//blank row
			row = sheet[sheetIndex].createRow(++rowCount);
			row = sheet[sheetIndex].createRow(++rowCount);
			cell = row.createCell(++columnCount);
			cell.setCellValue("S.No.");
			cell.setCellStyle(cellStyle);
			cell = row.createCell(++columnCount);
			cell.setCellValue("Application");
			cell.setCellStyle(cellStyle);
			cell = row.createCell(++columnCount);
			cell.setCellValue("Login status");
			cell.setCellStyle(cellStyle);
			cell = row.createCell(++columnCount);
			cell.setCellValue("Comments");
			cell.setCellStyle(cellStyle);

			//APP1-Ziggo NL
			strLoginURL=allproperties.getProperty("MYUPCAPP"+Integer.toString(appCounter)+"LOGINURL");
			strLoginUser=allproperties.getProperty("MYUPCAPP"+Integer.toString(appCounter)+"LOGINUSER");
			strLoginPassword=allproperties.getProperty("MYUPCAPP"+Integer.toString(appCounter)+"LOGINPASSWORD");
			strHomeURL=allproperties.getProperty("MYUPCAPP"+Integer.toString(appCounter)+"HOMEURL");
			strAppName=allproperties.getProperty("MYUPCAPP"+Integer.toString(appCounter)+"NAME");
			strLoginUser=strLoginUser.trim();
			strLoginPassword=strLoginPassword.trim();
			columnCount=0;
			row = sheet[sheetIndex].createRow(++rowCount);
			cell = row.createCell(++columnCount);
			cell.setCellValue(Integer.toString(counter++)); //S.no
			cell = row.createCell(++columnCount); 
			cell.setCellValue(strAppName);  //Application name
			cell = row.createCell(++columnCount); //for login status			
			open(strLoginURL);
			strHomeURL=strHomeURL.trim();
			//com.codeborne.selenide.WebDriverRunner.clearBrowserCache(); //clear cache
			Thread.sleep(20000);
			//check login page availability
			if(!($(By.name("userId")).exists())||!($(By.name("password")).exists())||!($(By.name("button")).exists())){
				cell.setCellValue(LOGINPAGEFAILERRORMSG);	
			}else{
				if($(By.name("userId")).exists()){
					$(By.name("userId")).shouldBe(visible);
					$(By.name("userId")).setValue(strLoginUser);
				}
				if($(By.name("password")).exists()){
					$(By.name("password")).setValue(strLoginPassword); }
				Thread.sleep(1000);
				//List<SelenideElement> list = $(By.id("background_fullwidth_templatesection-inner")).findAll(By.tagName("button"));
				//SelenideElement loginButton = list.get(0);
				//loginButton.click();
				if($(By.name("button")).exists()){
					$(By.name("button")).click();
					Thread.sleep(20000);
				}			
				strCurPageURL = (com.codeborne.selenide.WebDriverRunner.url()).trim();
				//handle all corner cases
				if(strCurPageURL.contains("error_code=0x132120c8")){
					cell.setCellValue(WRONGCREDSERRORMSG);	
				}
				else if((strCurPageURL.contains(strHomeURL))&&(!strCurPageURL.contains("error_code=0x132120c8"))){
					refresh(); //refresh page to close pop up
					Thread.sleep(20000);
					//login okay, but check correct home page landing
					if(($(By.id("msg_feedback_suster0")).getText()).contains("Welkom")&&($(By.className("lgi-utilnav-icon-avatar")).exists())){
						cell.setCellValue("Success");
						Thread.sleep(1000);  
						if($(By.className("lgi-utilnav-icon-avatar")).exists()){
							$(By.className("lgi-utilnav-icon-avatar")).click(); //expand menu
						}
						Thread.sleep(1000);
						if($(By.partialLinkText("uitloggen")).exists()){
							$(By.partialLinkText("uitloggen")).click();  //tap logout
						}					
					}else{
						cell.setCellValue(LANDINGFAILERRORMSG);
						//open("https://www.ziggo.nl/uitgelogd/"); //logging out manually
					}
					Thread.sleep(15000);				
				}else {
					//System.out.println("Login failed!!");
					cell.setCellValue(LOGINFAILERRORMSG);				
				}
			}

			System.out.println("[Info]: Ziggo NL done");
			appCounter++;			

			//APP2-UPC PL
			strLoginURL=allproperties.getProperty("MYUPCAPP"+Integer.toString(appCounter)+"LOGINURL");
			strLoginUser=allproperties.getProperty("MYUPCAPP"+Integer.toString(appCounter)+"LOGINUSER");
			strLoginPassword=allproperties.getProperty("MYUPCAPP"+Integer.toString(appCounter)+"LOGINPASSWORD");
			strHomeURL=allproperties.getProperty("MYUPCAPP"+Integer.toString(appCounter)+"HOMEURL");
			strAppName=allproperties.getProperty("MYUPCAPP"+Integer.toString(appCounter)+"NAME");
			strLoginUser=strLoginUser.trim();
			strLoginPassword=strLoginPassword.trim();
			columnCount=0;
			row = sheet[sheetIndex].createRow(++rowCount);
			cell = row.createCell(++columnCount);
			cell.setCellValue(Integer.toString(counter++));
			cell = row.createCell(++columnCount);
			cell.setCellValue(strAppName);
			cell = row.createCell(++columnCount);			
			open(strLoginUser); //open country page for proper flow
			Thread.sleep(20000);
			if($(By.partialLinkText("Moje UPC")).exists()){
				$(By.partialLinkText("Moje UPC")).click(); //tap on myupc login link
				Thread.sleep(25000);
			} 

			/*
			if($(By.id("my_upc_login_link")).exists()){
				$(By.id("my_upc_login_link")).click(); //tap on myupc login link
				Thread.sleep(20000);
			} */
			//check login page availability
			if(!($(By.name("username")).exists())||!($(By.name("password")).exists())||!($(By.id("submit")).exists())){
				cell.setCellValue(LOGINPAGEFAILERRORMSG);	
			}else{
				if($(By.name("username")).exists()){
					$(By.name("username")).shouldBe(visible);
					$(By.name("username")).setValue(strLoginUser);
				}
				if($(By.name("password")).exists()){
					$(By.name("password")).setValue(strLoginPassword); }
				Thread.sleep(1000);
				if($(By.id("submit")).exists()){
					$(By.id("submit")).click();
					Thread.sleep(20000);
				}
				//to close pop up, refresh the page
				refresh();
				Thread.sleep(20000);

				strCurPageURL = (com.codeborne.selenide.WebDriverRunner.url()).trim();
				//handle all corner cases
				if(strCurPageURL.contains("error_code=0x132120c8")){
					cell.setCellValue(WRONGCREDSERRORMSG);	
				}
				else if((strCurPageURL.startsWith(strHomeURL))&&(!strCurPageURL.contains("error_code=0x132120c8"))){
					//login okay, but check correct home page landing
					if(($(By.id("logo")).exists())&&(($(By.className("logout")).exists()))){
						cell.setCellValue("Success");
						//tap logout
						if($(By.partialLinkText("Wyloguj")).exists()){
							$(By.partialLinkText("Wyloguj")).click();  
						}
						if($(By.partialLinkText("Log out")).exists()){
							$(By.partialLinkText("Log out")).click();
						}
					}else{
						cell.setCellValue(LANDINGFAILERRORMSG);
					}
					Thread.sleep(10000);				
				}else {
					//System.out.println("Login failed!!");
					cell.setCellValue(LOGINFAILERRORMSG);				
				}
			}

			System.out.println("[Info]: MyUPC PL done");
			appCounter++;

			//APP3-UPC AT
			strLoginURL=allproperties.getProperty("MYUPCAPP"+Integer.toString(appCounter)+"LOGINURL");
			strLoginUser=allproperties.getProperty("MYUPCAPP"+Integer.toString(appCounter)+"LOGINUSER");
			strLoginPassword=allproperties.getProperty("MYUPCAPP"+Integer.toString(appCounter)+"LOGINPASSWORD");
			strHomeURL=allproperties.getProperty("MYUPCAPP"+Integer.toString(appCounter)+"HOMEURL");
			strAppName=allproperties.getProperty("MYUPCAPP"+Integer.toString(appCounter)+"NAME");
			strLoginUser=strLoginUser.trim();
			strLoginPassword=strLoginPassword.trim();
			columnCount=0;
			row = sheet[sheetIndex].createRow(++rowCount);
			cell = row.createCell(++columnCount);
			cell.setCellValue(Integer.toString(counter++));
			cell = row.createCell(++columnCount);
			cell.setCellValue(strAppName);
			cell = row.createCell(++columnCount);			
			open(strLoginURL);
			strHomeURL=strHomeURL.trim();
			Thread.sleep(20000);
			//check login page availability
			if(!($(By.name("username")).exists())||!($(By.name("password")).exists())||!($(By.id("loginBtn")).exists())){
				cell.setCellValue(LOGINPAGEFAILERRORMSG);	
			}else{
				if($(By.name("username")).exists()){
					$(By.name("username")).shouldBe(visible);
					$(By.name("username")).setValue(strLoginUser);
				}
				if($(By.name("password")).exists()){
					$(By.name("password")).setValue(strLoginPassword); }
				Thread.sleep(1000);
				if($(By.id("loginBtn")).exists()){
					$(By.id("loginBtn")).click();
					Thread.sleep(20000);
				}			
				strCurPageURL = (com.codeborne.selenide.WebDriverRunner.url()).trim();
				//handle all corner cases
				if(strCurPageURL.contains("0x132120c8")){
					cell.setCellValue(WRONGCREDSERRORMSG);	
				}
				else if((strCurPageURL.contains("TAM_OP=login_success"))||(strCurPageURL.equals(strHomeURL))&&(!strCurPageURL.contains("0x132120c8"))){
					//login okay, but check correct home page landing
					open(strHomeURL);  //just url redirects, so goto home page
					Thread.sleep(20000);

					if(($(By.id("MYUPC_child.logout_linkLogout")).exists())&&($(By.id("MYUPC_fixed.overview_dsPagename")).exists())&&($(By.className("sti-box-title")).exists())){
						cell.setCellValue("Success");
						$(By.id("MYUPC_child.logout_linkLogout")).click();//tap logout
					}
					else{
						cell.setCellValue(LANDINGFAILERRORMSG);
						open("http://www.upc.at/myupc/logout/"); //do logout by url
					}
					Thread.sleep(10000);				
				}else {
					//System.out.println("Login failed!!");
					cell.setCellValue(LOGINFAILERRORMSG);				
				}
			}

			System.out.println("[Info]: MyUPC AT done");
			appCounter++;

			//APP4-UPC CH
			strLoginURL=allproperties.getProperty("MYUPCAPP"+Integer.toString(appCounter)+"LOGINURL");
			strLoginUser=allproperties.getProperty("MYUPCAPP"+Integer.toString(appCounter)+"LOGINUSER");
			strLoginPassword=allproperties.getProperty("MYUPCAPP"+Integer.toString(appCounter)+"LOGINPASSWORD");
			strHomeURL=allproperties.getProperty("MYUPCAPP"+Integer.toString(appCounter)+"HOMEURL");
			strAppName=allproperties.getProperty("MYUPCAPP"+Integer.toString(appCounter)+"NAME");
			strLoginUser=strLoginUser.trim();
			strLoginPassword=strLoginPassword.trim();
			columnCount=0;
			row = sheet[sheetIndex].createRow(++rowCount);
			cell = row.createCell(++columnCount);
			cell.setCellValue(Integer.toString(counter++));
			cell = row.createCell(++columnCount);
			cell.setCellValue(strAppName);
			cell = row.createCell(++columnCount);			

			open(strLoginURL);
			strHomeURL=strHomeURL.trim();
			Thread.sleep(25000);
			//check login page availability
			if(!($(By.name("userId")).exists())||!($(By.name("password")).exists())||!($(By.name("button")).exists())){
				cell.setCellValue(LOGINPAGEFAILERRORMSG);	
			}else{
				if($(By.name("userId")).exists()){
					$(By.name("userId")).shouldBe(visible);
					$(By.name("userId")).setValue(strLoginUser);
				}
				if($(By.name("password")).exists()){
					$(By.name("password")).setValue(strLoginPassword); }
				Thread.sleep(1000);
				if($(By.name("button")).exists()){
					$(By.name("button")).click();
					Thread.sleep(25000);
				}
				strCurPageURL = (com.codeborne.selenide.WebDriverRunner.url()).trim();
				//handle all corner cases
				if(strCurPageURL.contains("0x132120c8")){
					cell.setCellValue(WRONGCREDSERRORMSG);	
				}
				else if((strCurPageURL.contains("TAM_OP=login_success"))||(strCurPageURL.contains(strHomeURL))&&(!strCurPageURL.contains("0x132120c8"))){
					//login okay, but check correct home page landing	
					if(($(By.className("customer_name_display")).exists())&&($(By.className("upc_logo")).exists())){
						cell.setCellValue("Success");
					}
					else{
						cell.setCellValue(LANDINGFAILERRORMSG);
					}
					//logout manually
					open("https://www.upc.ch/pkmsLogout/?toUrl=/en/account/logged-out");
					Thread.sleep(10000);				
				}else {
					//System.out.println("Login failed!!");
					cell.setCellValue(LOGINFAILERRORMSG);				
				}
			}
			System.out.println("[Info]: MyUPC CH done");
			appCounter++;

			//APP5-MyUPC RO
			strLoginURL=allproperties.getProperty("MYUPCAPP"+Integer.toString(appCounter)+"LOGINURL");
			strLoginUser=allproperties.getProperty("MYUPCAPP"+Integer.toString(appCounter)+"LOGINUSER");
			strLoginPassword=allproperties.getProperty("MYUPCAPP"+Integer.toString(appCounter)+"LOGINPASSWORD");
			strHomeURL=allproperties.getProperty("MYUPCAPP"+Integer.toString(appCounter)+"HOMEURL");
			strAppName=allproperties.getProperty("MYUPCAPP"+Integer.toString(appCounter)+"NAME");
			strLoginUser=strLoginUser.trim();
			strLoginPassword=strLoginPassword.trim();
			columnCount=0;
			row = sheet[sheetIndex].createRow(++rowCount);
			cell = row.createCell(++columnCount);
			cell.setCellValue(Integer.toString(counter++));
			cell = row.createCell(++columnCount);
			cell.setCellValue(strAppName);
			cell = row.createCell(++columnCount);			
			open(strLoginURL);
			strHomeURL=strHomeURL.trim();
			Thread.sleep(20000);
			//check login page availability
			if(!($(By.name("inputEmail")).exists())||!($(By.name("password")).exists())||!($(By.id("formlogin")).exists())){
				cell.setCellValue(LOGINPAGEFAILERRORMSG);	
			}else{
				if($(By.name("inputEmail")).exists()){
					$(By.name("inputEmail")).shouldBe(visible);
					$(By.name("inputEmail")).setValue(strLoginUser);
				}
				if($(By.name("password")).exists()){
					$(By.name("password")).setValue(strLoginPassword); }
				Thread.sleep(1000);
				if($(By.id("formlogin")).exists()){
					list = $(By.id("formlogin")).findAll(By.tagName("button"));
					loginButton = list.get(0);
					loginButton.click();
					Thread.sleep(20000);				
				}			
				strCurPageURL = (com.codeborne.selenide.WebDriverRunner.url()).trim();
				//handle all corner cases
				if(($(By.id("errorsinput-error")).exists())&&!(strCurPageURL.contains(strHomeURL))){
					cell.setCellValue(WRONGCREDSERRORMSG);	
				}
				else if((strCurPageURL.contains("TAM_OP=login_success"))||(strCurPageURL.contains(strHomeURL))&&(!strCurPageURL.contains("0x132120c8"))){
					//login okay, but check correct home page landing	
					if(($(By.className("navbar-brand")).exists())&&($(By.className("logoutClass")).exists())){
						cell.setCellValue("Success");
						if($(By.className("logoutClass")).exists()){
							$(By.className("logoutClass")).click();
						}
					}
					else{
						cell.setCellValue(LANDINGFAILERRORMSG);
					}
					Thread.sleep(10000);				
				}else {
					//System.out.println("Login failed!!");
					cell.setCellValue(LOGINFAILERRORMSG);				
				}			
			}		

			System.out.println("[Info]: MyUPC RO done");
			appCounter++;

			//APP6-IAM SK
			strLoginURL=allproperties.getProperty("MYUPCAPP"+Integer.toString(appCounter)+"LOGINURL");
			strLoginUser=allproperties.getProperty("MYUPCAPP"+Integer.toString(appCounter)+"LOGINUSER");
			strLoginPassword=allproperties.getProperty("MYUPCAPP"+Integer.toString(appCounter)+"LOGINPASSWORD");
			strHomeURL=allproperties.getProperty("MYUPCAPP"+Integer.toString(appCounter)+"HOMEURL");
			strAppName=allproperties.getProperty("MYUPCAPP"+Integer.toString(appCounter)+"NAME");
			strLoginUser=strLoginUser.trim();
			strLoginPassword=strLoginPassword.trim();
			columnCount=0;
			row = sheet[sheetIndex].createRow(++rowCount);
			cell = row.createCell(++columnCount);
			cell.setCellValue(Integer.toString(counter++));
			cell = row.createCell(++columnCount);
			cell.setCellValue(strAppName);
			cell = row.createCell(++columnCount);			
			open(strLoginURL);
			strHomeURL=strHomeURL.trim();
			Thread.sleep(20000);
			//check login page availability
			if(!($(By.name("userId")).exists())||!($(By.name("password")).exists())||!($(By.name("button")).exists())){
				cell.setCellValue(LOGINPAGEFAILERRORMSG);	
			}else{
				if($(By.name("userId")).exists()){
					$(By.name("userId")).shouldBe(visible);
					$(By.name("userId")).setValue(strLoginUser);
				}
				if($(By.name("password")).exists()){
					$(By.name("password")).setValue(strLoginPassword); }
				Thread.sleep(1000);
				if($(By.name("button")).exists()){
					$(By.name("button")).click(); 
				}
				Thread.sleep(20000);
				strCurPageURL = (com.codeborne.selenide.WebDriverRunner.url()).trim();
				//handle all corner cases
				if(strCurPageURL.contains("0x132120c8")){
					cell.setCellValue(WRONGCREDSERRORMSG);	
				}
				else if((strCurPageURL.contains("TAM_OP=login_success"))||(strCurPageURL.contains(strHomeURL))&&(!strCurPageURL.contains("0x132120c8"))){
					//login okay, but check correct home page landing	
					if(($(By.className("home-ico")).exists())&&($(By.className("upc_logo")).exists())&&(($(By.className("container-whole")).getText()).contains("Vitajte")||($(By.className("container-whole")).getText()).contains("Welcome"))){
						cell.setCellValue("Success");
					}else{
						cell.setCellValue(LANDINGFAILERRORMSG);
					}

				}else {
					//System.out.println("Login failed!!");
					cell.setCellValue(LOGINFAILERRORMSG);				
				}
				open("https://www.upc.sk/pkmsLogout/"); //do manually, logout option not available
				Thread.sleep(10000);					
			}

			System.out.println("[Info]: IAM SK done");
			appCounter++;

			//com.codeborne.selenide.WebDriverRunner.clearBrowserCache(); //clear cache
			//APP7-IAM HU
			strLoginURL=allproperties.getProperty("MYUPCAPP"+Integer.toString(appCounter)+"LOGINURL");
			strLoginUser=allproperties.getProperty("MYUPCAPP"+Integer.toString(appCounter)+"LOGINUSER");
			strLoginPassword=allproperties.getProperty("MYUPCAPP"+Integer.toString(appCounter)+"LOGINPASSWORD");
			strHomeURL=allproperties.getProperty("MYUPCAPP"+Integer.toString(appCounter)+"HOMEURL");
			strAppName=allproperties.getProperty("MYUPCAPP"+Integer.toString(appCounter)+"NAME");
			strLoginUser=strLoginUser.trim();
			strLoginPassword=strLoginPassword.trim();
			columnCount=0;
			row = sheet[sheetIndex].createRow(++rowCount);
			cell = row.createCell(++columnCount);
			cell.setCellValue(Integer.toString(counter++));
			cell = row.createCell(++columnCount);
			cell.setCellValue(strAppName);
			cell = row.createCell(++columnCount);			
			open(strLoginURL);
			strHomeURL=strHomeURL.trim();
			Thread.sleep(30000);
			//check login page availability
			if(!($(By.name("userId")).exists())||!($(By.name("password")).exists())||!($(By.name("button")).exists())){
				cell.setCellValue(LOGINPAGEFAILERRORMSG);	
			}else{
				if($(By.name("userId")).exists()){
					$(By.name("userId")).shouldBe(visible);
					$(By.name("userId")).setValue(strLoginUser);
				}
				if($(By.name("password")).exists()){
					$(By.name("password")).setValue(strLoginPassword); }
				Thread.sleep(1000);
				if($(By.name("button")).exists()){
					$(By.name("button")).click(); 
				}
				Thread.sleep(35000);
				strCurPageURL = (com.codeborne.selenide.WebDriverRunner.url()).trim();
				//handle all corner cases
				if(strCurPageURL.contains("0x132120c8")){
					cell.setCellValue(WRONGCREDSERRORMSG);	
				}
				else if((strCurPageURL.contains("TAM_OP=login_success"))||(strCurPageURL.contains(strHomeURL))&&(!strCurPageURL.contains("0x132120c8"))){
					//login okay, but check correct home page landing	
					if(($(By.className("home-ico")).exists())&&($(By.className("upc_logo")).exists())&&(($(By.className("index-title")).getText()).contains("�dv�zl�nk")||($(By.className("index-title")).getText()).contains("Welcome"))){
						cell.setCellValue("Success");

					}else{
						cell.setCellValue(LANDINGFAILERRORMSG);
					}
					open("https://www.upc.hu/pkmsLogout/");	
					Thread.sleep(10000);				
				}else {
					//System.out.println("Login failed!!");
					cell.setCellValue(LOGINFAILERRORMSG);				
				}
			}

			System.out.println("[Info]: IAM HU done");
			appCounter++;

			//APP8-MyVirginmedia IE - (MyUPC IE)
			strLoginURL=allproperties.getProperty("MYUPCAPP"+Integer.toString(appCounter)+"LOGINURL");
			strLoginUser=allproperties.getProperty("MYUPCAPP"+Integer.toString(appCounter)+"LOGINUSER");
			strLoginPassword=allproperties.getProperty("MYUPCAPP"+Integer.toString(appCounter)+"LOGINPASSWORD");
			strHomeURL=allproperties.getProperty("MYUPCAPP"+Integer.toString(appCounter)+"HOMEURL");
			strAppName=allproperties.getProperty("MYUPCAPP"+Integer.toString(appCounter)+"NAME");
			strLoginUser=strLoginUser.trim();
			strLoginPassword=strLoginPassword.trim();
			columnCount=0;
			row = sheet[sheetIndex].createRow(++rowCount);
			cell = row.createCell(++columnCount);
			cell.setCellValue(Integer.toString(counter++));
			cell = row.createCell(++columnCount);
			cell.setCellValue(strAppName);
			cell = row.createCell(++columnCount);			
			open(strLoginURL); //actually opens VM IE home page
			strHomeURL=strHomeURL.trim();
			Thread.sleep(15000);
			if($(By.id("myvirginmedia-title")).exists()){ //now open login page
				$(By.id("myvirginmedia-title")).click(); //expand menu
				if($(By.id("myvirginmedia-login")).exists()){
					$(By.id("myvirginmedia-login")).click(); //tap on 'Sign In'
					Thread.sleep(10000);
				}
			}
			//check login page availability
			if(!($(By.name("username")).exists())||!($(By.name("password")).exists())||!($(By.id("background_fullwidth_templatesection_section_content_authandlerloginbox_button")).exists())){
				cell.setCellValue(LOGINPAGEFAILERRORMSG);	
			}else{
				if($(By.name("username")).exists()){
					$(By.name("username")).shouldBe(visible);
					$(By.name("username")).setValue(strLoginUser);
				}
				if($(By.name("password")).exists()){
					$(By.name("password")).setValue(strLoginPassword); }
				Thread.sleep(1000);
				if($(By.id("background_fullwidth_templatesection_section_content_authandlerloginbox_button")).exists()){			
					$(By.id("background_fullwidth_templatesection_section_content_authandlerloginbox_button")).click();
				}
				Thread.sleep(15000);
				strCurPageURL = (com.codeborne.selenide.WebDriverRunner.url()).trim();
				//handle all corner cases
				if(strCurPageURL.contains("0x132120c8")){
					cell.setCellValue("[Error]: Login failed, Username or password is incorrect. Please check immediately!!");	
				}
				else if((strCurPageURL.contains("TAM_OP=login_success"))||(strCurPageURL.contains(strHomeURL))&&(!strCurPageURL.contains("0x132120c8"))){
					//login okay, but check correct home page landing	
					if(($(By.id("myvirginmedia-username")).exists())&&($(By.id("under-header-image-main")).getText()).contains("Welcome to My Virgin Media!")){
						cell.setCellValue("Success");
						if($(By.id("myvirginmedia-username")).exists()){ $(By.id("myvirginmedia-username")).click(); } //expand menu
						if($(By.id("myvirginmedia-logout")).exists()){ $(By.id("myvirginmedia-logout")).click(); } //tap on 'Log out'
					}else{
						cell.setCellValue(LANDINGFAILERRORMSG);
						open("https://www.virginmedia.ie/pkmslogout/"); //logout manually
					}
					Thread.sleep(8000);				
				}else {
					//System.out.println("Login failed!!");
					cell.setCellValue("[Error]: Login failed, Please check immediately!!");				
				}				
			}

			System.out.println("[Info]: MyVirginmedia IE done");
			//appCounter++;

			//Check for 8 Horizon go application login status
			for (appCounter=1;appCounter<=NOOFHZGOAPPLICATIONS;appCounter++){
				strLoginURL=allproperties.getProperty("HZGOAPP"+Integer.toString(appCounter)+"LOGINURL");
				strLoginUser=allproperties.getProperty("HZGOAPP"+Integer.toString(appCounter)+"LOGINUSER");
				strLoginPassword=allproperties.getProperty("HZGOAPP"+Integer.toString(appCounter)+"LOGINPASSWORD");
				strAppName=allproperties.getProperty("HZGOAPP"+Integer.toString(appCounter)+"NAME");
				strLoginUser=strLoginUser.trim();
				strLoginPassword=strLoginPassword.trim();
				columnCount=0;
				row = sheet[sheetIndex].createRow(++rowCount);
				cell = row.createCell(++columnCount);
				cell.setCellValue(Integer.toString(counter++)); //S.no
				cell = row.createCell(++columnCount); 
				cell.setCellValue(strAppName);  //Application name
				cell = row.createCell(++columnCount); //for login status			
				//com.codeborne.selenide.WebDriverRunner.clearBrowserCache(); //clear browser cache
				open(strLoginURL);
				Thread.sleep(10000); //wait until page gets loaded properly
				//Horizon GO logo & login link should be visible
				//check login page availability
				if(!(($(By.id("utility-signin-link")).exists()) || !($(By.className("logotype")).exists()))){
					cell.setCellValue(LOGINPAGEFAILERRORMSG);	
				}else{
					if(($(By.id("utility-signin-link")).exists() && $(By.className("logotype")).exists())){
						$(By.id("utility-signin-link")).click();
						Thread.sleep(10000);
						//Enter credentials
						if($(By.name("username")).exists()){
							$(By.name("username")).shouldBe(visible);
							$(By.name("username")).setValue(strLoginUser);
						}
						if($(By.name("password")).exists()){
							$(By.name("password")).setValue(strLoginPassword); }
						if($(By.id("login-submit-button")).exists()){
							$(By.id("login-submit-button")).click();
							Thread.sleep(10000);
						}	
						//check if provided credentials were wrong?
						if($(By.className("error")).exists()){
							cell.setCellValue(WRONGCREDSERRORMSG);
						}else{
							// reload page to close pop up msg, if arises
							refresh();
							Thread.sleep(10000);
							//expand user-menu post login
							if($(By.id("welcome-username")).exists()){ 
								$(By.id("welcome-username")).click();
								Thread.sleep(1000);				
								//do logout from application
								if($(By.id("sign-out-link")).exists()){
									$(By.id("sign-out-link")).click();
									Thread.sleep(10000);
								}	
								cell.setCellValue("Success");
							}else{
								cell.setCellValue(LOGINFAILERRORMSG);
							}
						}	
					}else{
						cell.setCellValue(LOGINPAGEFAILERRORMSG);
					}
				}				
				System.out.println("[Info]: "+strAppName+" done");
			}
			
			/*			

			//APP10-HORIZON GO DE
			strLoginURL=allproperties.getProperty("HZGOAPP"+Integer.toString(appCounter)+"LOGINURL");
			strLoginUser=allproperties.getProperty("HZGOAPP"+Integer.toString(appCounter)+"LOGINUSER");
			strLoginPassword=allproperties.getProperty("HZGOAPP"+Integer.toString(appCounter)+"LOGINPASSWORD");
			strAppName=allproperties.getProperty("HZGOAPP"+Integer.toString(appCounter)+"NAME");
			strLoginUser=strLoginUser.trim();
			strLoginPassword=strLoginPassword.trim();
			columnCount=0;
			row = sheet[sheetIndex].createRow(++rowCount);
			cell = row.createCell(++columnCount);
			cell.setCellValue(Integer.toString(counter++)); //S.no
			cell = row.createCell(++columnCount); 
			cell.setCellValue(strAppName);  //Application name
			cell = row.createCell(++columnCount); //for login status			
			open(strLoginURL);
			Thread.sleep(10000); //wait until page gets loaded properly
			//Horizon GO logo & login link should be visible
			if(($(By.id("utility-signin-link")).exists() && $(By.className("logotype")).exists())){
				$(By.id("utility-signin-link")).click();
				Thread.sleep(10000);
				//Enter credentials
				if($(By.name("username")).exists()){
					$(By.name("username")).shouldBe(visible);
					$(By.name("username")).setValue(strLoginUser);
				}
				if($(By.name("password")).exists()){
					$(By.name("password")).setValue(strLoginPassword); }
				if($(By.id("login-submit-button")).exists()){
					$(By.id("login-submit-button")).click();
					Thread.sleep(10000);
				}	
				//check if provided credentials were wrong?
				if($(By.className("error")).exists()){
					cell.setCellValue(WRONGCREDSERRORMSG);
				}else{
					// reload page to close pop up msg, if arises
					refresh();
					Thread.sleep(10000);
					//expand user-menu post login
					if($(By.id("welcome-username")).exists()){ 
						$(By.id("welcome-username")).click();
						Thread.sleep(1000);				
						//do logout from application
						if($(By.id("sign-out-link")).exists()){
							$(By.id("sign-out-link")).click();
							Thread.sleep(10000);
						}	
						cell.setCellValue("Success");
					}else{
						cell.setCellValue(LOGINFAILERRORMSG);
					}
				}	
			}else{
				cell.setCellValue(LOGINPAGEFAILERRORMSG);
			}
			System.out.println("[Info]: Horizon Go DE done");
			appCounter++;

			//APP11-HORIZON GO PL
			strLoginURL=allproperties.getProperty("HZGOAPP"+Integer.toString(appCounter)+"LOGINURL");
			strLoginUser=allproperties.getProperty("HZGOAPP"+Integer.toString(appCounter)+"LOGINUSER");
			strLoginPassword=allproperties.getProperty("HZGOAPP"+Integer.toString(appCounter)+"LOGINPASSWORD");
			strAppName=allproperties.getProperty("HZGOAPP"+Integer.toString(appCounter)+"NAME");
			strLoginUser=strLoginUser.trim();
			strLoginPassword=strLoginPassword.trim();
			columnCount=0;
			row = sheet[sheetIndex].createRow(++rowCount);
			cell = row.createCell(++columnCount);
			cell.setCellValue(Integer.toString(counter++)); //S.no
			cell = row.createCell(++columnCount); 
			cell.setCellValue(strAppName);  //Application name
			cell = row.createCell(++columnCount); //for login status			
			open(strLoginURL);
			Thread.sleep(10000); //wait until page gets loaded properly
			//Horizon GO logo & login link should be visible
			if(($(By.id("utility-signin-link")).exists() && $(By.className("logotype")).exists())){
				$(By.id("utility-signin-link")).click();
				Thread.sleep(10000);
				//Enter credentials
				if($(By.name("username")).exists()){
					$(By.name("username")).shouldBe(visible);
					$(By.name("username")).setValue(strLoginUser);
				}
				if($(By.name("password")).exists()){
					$(By.name("password")).setValue(strLoginPassword); }
				if($(By.id("login-submit-button")).exists()){
					$(By.id("login-submit-button")).click();
					Thread.sleep(10000);
				}	
				//check if provided credentials were wrong?
				if($(By.className("error")).exists()){
					cell.setCellValue(WRONGCREDSERRORMSG);
				}else{
					// reload page to close pop up msg, if arises
					refresh();
					Thread.sleep(10000);
					//expand user-menu post login
					if($(By.id("welcome-username")).exists()){ 
						$(By.id("welcome-username")).click();
						Thread.sleep(1000);				
						//do logout from application
						if($(By.id("sign-out-link")).exists()){
							$(By.id("sign-out-link")).click();
							Thread.sleep(10000);
						}	
						cell.setCellValue("Success");
					}else{
						cell.setCellValue(LOGINFAILERRORMSG);
					}
				}	
			}else{
				cell.setCellValue(LOGINPAGEFAILERRORMSG);
			}
			System.out.println("[Info]: Horizon Go PL done");
			appCounter++;

			//APP12-HORIZON GO RO
			strLoginURL=allproperties.getProperty("HZGOAPP"+Integer.toString(appCounter)+"LOGINURL");
			strLoginUser=allproperties.getProperty("HZGOAPP"+Integer.toString(appCounter)+"LOGINUSER");
			strLoginPassword=allproperties.getProperty("HZGOAPP"+Integer.toString(appCounter)+"LOGINPASSWORD");
			strAppName=allproperties.getProperty("HZGOAPP"+Integer.toString(appCounter)+"NAME");
			strLoginUser=strLoginUser.trim();
			strLoginPassword=strLoginPassword.trim();
			columnCount=0;
			row = sheet[sheetIndex].createRow(++rowCount);
			cell = row.createCell(++columnCount);
			cell.setCellValue(Integer.toString(counter++)); //S.no
			cell = row.createCell(++columnCount); 
			cell.setCellValue(strAppName);  //Application name
			cell = row.createCell(++columnCount); //for login status			
			open(strLoginURL);
			Thread.sleep(10000); //wait until page gets loaded properly
			//Horizon GO logo & login link should be visible
			if(($(By.id("utility-signin-link")).exists() && $(By.className("logotype")).exists())){
				$(By.id("utility-signin-link")).click();
				Thread.sleep(10000);
				//Enter credentials
				if($(By.name("username")).exists()){
					$(By.name("username")).shouldBe(visible);
					$(By.name("username")).setValue(strLoginUser);
				}
				if($(By.name("password")).exists()){
					$(By.name("password")).setValue(strLoginPassword); }
				if($(By.id("login-submit-button")).exists()){
					$(By.id("login-submit-button")).click();
					Thread.sleep(10000);
				}	
				//check if provided credentials were wrong?
				if($(By.className("error")).exists()){
					cell.setCellValue(WRONGCREDSERRORMSG);
				}else{
					// reload page to close pop up msg, if arises
					refresh();
					Thread.sleep(10000);
					//expand user-menu post login
					if($(By.id("welcome-username")).exists()){ 
						$(By.id("welcome-username")).click();
						Thread.sleep(1000);				
						//do logout from application
						if($(By.id("sign-out-link")).exists()){
							$(By.id("sign-out-link")).click();
							Thread.sleep(10000);
						}	
						cell.setCellValue("Success");
					}else{
						cell.setCellValue(LOGINFAILERRORMSG);
					}
				}	
			}else{
				cell.setCellValue(LOGINPAGEFAILERRORMSG);
			}
			System.out.println("[Info]: Horizon Go RO done");
			appCounter++;

			//APP13-HORIZON GO HU
			strLoginURL=allproperties.getProperty("HZGOAPP"+Integer.toString(appCounter)+"LOGINURL");
			strLoginUser=allproperties.getProperty("HZGOAPP"+Integer.toString(appCounter)+"LOGINUSER");
			strLoginPassword=allproperties.getProperty("HZGOAPP"+Integer.toString(appCounter)+"LOGINPASSWORD");
			strAppName=allproperties.getProperty("HZGOAPP"+Integer.toString(appCounter)+"NAME");
			strLoginUser=strLoginUser.trim();
			strLoginPassword=strLoginPassword.trim();
			columnCount=0;
			row = sheet[sheetIndex].createRow(++rowCount);
			cell = row.createCell(++columnCount);
			cell.setCellValue(Integer.toString(counter++)); //S.no
			cell = row.createCell(++columnCount); 
			cell.setCellValue(strAppName);  //Application name
			cell = row.createCell(++columnCount); //for login status			
			open(strLoginURL);
			Thread.sleep(10000); //wait until page gets loaded properly
			//Horizon GO logo & login link should be visible
			if(($(By.id("utility-signin-link")).exists() && $(By.className("logotype")).exists())){
				$(By.id("utility-signin-link")).click();
				Thread.sleep(10000);
				//Enter credentials
				if($(By.name("username")).exists()){
					$(By.name("username")).shouldBe(visible);
					$(By.name("username")).setValue(strLoginUser);
				}
				if($(By.name("password")).exists()){
					$(By.name("password")).setValue(strLoginPassword); }
				if($(By.id("login-submit-button")).exists()){
					$(By.id("login-submit-button")).click();
					Thread.sleep(10000);
				}	
				//check if provided credentials were wrong?
				if($(By.className("error")).exists()){
					cell.setCellValue(WRONGCREDSERRORMSG);
				}else{
					// reload page to close pop up msg, if arises
					refresh();
					Thread.sleep(10000);
					//expand user-menu post login
					if($(By.id("welcome-username")).exists()){ 
						$(By.id("welcome-username")).click();
						Thread.sleep(1000);				
						//do logout from application
						if($(By.id("sign-out-link")).exists()){
							$(By.id("sign-out-link")).click();
							Thread.sleep(10000);
						}	
						cell.setCellValue("Success");
					}else{
						cell.setCellValue(LOGINFAILERRORMSG);
					}
				}	
			}else{
				cell.setCellValue(LOGINPAGEFAILERRORMSG);
			}
			System.out.println("[Info]: Horizon Go HU done");
			appCounter++;

			//APP14-HORIZON GO SK
			strLoginURL=allproperties.getProperty("HZGOAPP"+Integer.toString(appCounter)+"LOGINURL");
			strLoginUser=allproperties.getProperty("HZGOAPP"+Integer.toString(appCounter)+"LOGINUSER");
			strLoginPassword=allproperties.getProperty("HZGOAPP"+Integer.toString(appCounter)+"LOGINPASSWORD");
			strAppName=allproperties.getProperty("HZGOAPP"+Integer.toString(appCounter)+"NAME");
			strLoginUser=strLoginUser.trim();
			strLoginPassword=strLoginPassword.trim();
			columnCount=0;
			row = sheet[sheetIndex].createRow(++rowCount);
			cell = row.createCell(++columnCount);
			cell.setCellValue(Integer.toString(counter++)); //S.no
			cell = row.createCell(++columnCount); 
			cell.setCellValue(strAppName);  //Application name
			cell = row.createCell(++columnCount); //for login status			
			open(strLoginURL);
			Thread.sleep(10000); //wait until page gets loaded properly
			//Horizon GO logo & login link should be visible
			if(($(By.id("utility-signin-link")).exists() && $(By.className("logotype")).exists())){
				$(By.id("utility-signin-link")).click();
				Thread.sleep(10000);
				//Enter credentials
				if($(By.name("username")).exists()){
					$(By.name("username")).shouldBe(visible);
					$(By.name("username")).setValue(strLoginUser);
				}
				if($(By.name("password")).exists()){
					$(By.name("password")).setValue(strLoginPassword); }
				if($(By.id("login-submit-button")).exists()){
					$(By.id("login-submit-button")).click();
					Thread.sleep(10000);
				}	
				//check if provided credentials were wrong?
				if($(By.className("error")).exists()){
					cell.setCellValue(WRONGCREDSERRORMSG);
				}else{
					// reload page to close pop up msg, if arises
					refresh();
					Thread.sleep(10000);
					//expand user-menu post login
					if($(By.id("welcome-username")).exists()){ 
						$(By.id("welcome-username")).click();
						Thread.sleep(1000);				
						//do logout from application
						if($(By.id("sign-out-link")).exists()){
							$(By.id("sign-out-link")).click();
							Thread.sleep(10000);
						}	
						cell.setCellValue("Success");
					}else{
						cell.setCellValue(LOGINFAILERRORMSG);
					}
				}	
			}else{
				cell.setCellValue(LOGINPAGEFAILERRORMSG);
			}
			System.out.println("[Info]: Horizon Go SK done");
			appCounter++;
            */
		}
		catch(Exception e){
			try {
				bw.write(e.toString());
			} catch (IOException e1) {
				e1.printStackTrace();
			}
		}
	}
}
