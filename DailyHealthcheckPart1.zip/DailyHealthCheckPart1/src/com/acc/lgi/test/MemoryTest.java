package com.acc.lgi.test;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.util.Properties;
import java.util.StringTokenizer;

import com.jcraft.jsch.Channel;
import com.jcraft.jsch.ChannelExec;
import com.jcraft.jsch.ChannelShell;
import com.jcraft.jsch.JSch;
import com.jcraft.jsch.JSchException;
import com.jcraft.jsch.Session;

public class MemoryTest {

	public static void main(String[] args) {
		System.out.println("Started now ..");
		//checkMemoryStatusThruAdminSSH("172.28.52.15","amspsdpie01","172.28.52.24");
		//openSSHNCheckMemoryStatus("172.28.52.15","amspsdpie01","172.28.52.24");
		//checkMemoryStatusThruAdminSSH("172.28.52.15","amspsdpie01","172.28.52.24");
		//checkMemoryStatusThruAdminSSH("172.28.48.177","amspichhu05","172.28.48.177");
		checkMemoryStatusThruAdminSSH("172.28.48.177","amspichhu05","172.28.48.172");
		System.out.println("- Done -");
	}

	//check memory status of servers through admin server
	private static void checkMemoryStatusThruAdminSSH_Old(String strAdminServerIP,String strHostName, String strServerIP) {
		Channel channel = null;
		Session session = null;
		String line = null;
		try{
			String strMemoryUsed=null,strMemoryFree=null,strCacheUsed=null,strCacheFree=null,strCmdOutput=null;
			String command1 = "ssh -o \"StrictHostKeyChecking no\" "+strServerIP;
			String command2 = "free -m";
			String host=strAdminServerIP; 
			String user="vsaripalli01";
			String password="Rogerthat&7";

			JSch jsch = new JSch();
			session = jsch.getSession(user, host, 22);
			Properties config = new Properties();	
			config.put("StrictHostKeyChecking", "no");
			session.setConfig(config);;
			session.setPassword(password);
			session.connect();

			channel = session.openChannel("shell");
			channel.setInputStream(null);
			channel.setOutputStream(null);

			InputStream in = channel.getInputStream();
			OutputStream out = channel.getOutputStream();
			((ChannelShell)channel).setPtyType("vt102");
			channel.connect();

			//out.write(("ssh -o UserKnownHostsFile=/dev/null -o StrictHostKeyChecking=no").getBytes());
			//out.write(("\n").getBytes());
			out.write((command1).getBytes());
			out.write(("\n").getBytes());
			out.write((command2).getBytes());
			out.write(("\nexit\n").getBytes());
			out.flush();

			try{
				InputStreamReader inputReader = new InputStreamReader(in);
				BufferedReader bufferedReader = new BufferedReader(inputReader);
				int counter=0; 

				while((line = bufferedReader.readLine()) != null){
					System.out.println(line);
					strCmdOutput = line.trim();

					if(strCmdOutput.startsWith("Mem:")){
						//split strings into array irrespective of no.of spaces
						String[] parts = strCmdOutput.split("[ ]{2,}");
						for(String value:parts){
							counter++;
							if(counter==3){ strMemoryUsed=value;}
							else if(counter==4){ strMemoryFree=value; }
						}
						line = bufferedReader.readLine();
						strCmdOutput = line.trim();
						parts = strCmdOutput.split("[ ]{2,}");
						counter=0; 
						for(String value:parts){
							counter++;
							if(counter==2){ strCacheUsed=value; }
							else if(counter==3){ strCacheFree=value; }

						}
					}
					if((strCmdOutput).equals("logout")){
						break;
					}
				}
				bufferedReader.close();
				inputReader.close();
				in.close();
				//write memory status results to excel

			}catch(IOException ex){
				ex.printStackTrace();
			}

		}catch(Exception ex){
			ex.printStackTrace();
		}
		finally{
			//If Unix box is not up then?
			if((null==line)){
				System.out.println("Unable to connect to the server!");
			}
			if(null!=channel)channel.disconnect();
			if(null!=session)session.disconnect();
		}
	}

	//check memory status of servers through admin server
	private static void checkMemoryStatusThruAdminSSH(String strAdminServerIP,String strHostName, String strServerIP) {	
		String strMemoryUsed=null,strMemoryFree=null,strCacheUsed=null,strCacheFree=null;
		StringTokenizer str=null;
		Channel channel2=null,channel1=null;;
		Session session=null;
		String command1 = "ssh -o \"StrictHostKeyChecking no\" "+strServerIP;
		String command2 = "free -m";	
		byte[] tmp=null;
		try{
			java.util.Properties config = new java.util.Properties(); 
			config.put("StrictHostKeyChecking", "no");
			JSch jsch = new JSch();
			session=jsch.getSession("vsaripalli01",strAdminServerIP, 22);
			session.setPassword("Rogerthat&7");
			session.setConfig(config);
			session.connect();

			channel1=session.openChannel("exec");
			channel2=session.openChannel("exec");

			((ChannelExec)channel1).setCommand(command1);
			channel1.setInputStream(null);
			((ChannelExec)channel2).setCommand(command2);
			channel2.setInputStream(null);
			((ChannelExec)channel2).setErrStream(System.err);

			InputStream in=channel1.getInputStream();
			channel1.connect();
			Thread.sleep(2000);
			//in1.close();
			/*
			while(true){
				String strCmdOutput;
				//while runs only once, because total o/p is less than 1024 bytes
				in1.read();
				//
				if(channel1.isClosed()){
					break;
				}
				try{Thread.sleep(1000);}catch(Exception ee){}
			}*/

			//((ChannelExec)channel1).setCommand(command2);
			//channel1.setInputStream(null);
			in=channel2.getInputStream();
			channel2.connect();

			tmp=new byte[1024];
			while(true){
				String strCmdOutput;
				//while runs only once, because total o/p is less than 1024 bytes
				while(in.available()>0){ 
					int i=in.read(tmp, 0, 1024);
					if(i<0)break;
					strCmdOutput = new String(tmp, 0, i);
					System.out.print(strCmdOutput);
					String[] parts = strCmdOutput.split("[ ]{2,}");//.split("\\s{2,}");
					//Extract only required values from command output
					strMemoryUsed=parts[8];
					strMemoryFree=parts[9];
					strCacheUsed=parts[13];
					str=new StringTokenizer(parts[14],"Swap:");
					strCacheFree=(str.nextToken()).trim();
				}
				if(channel1.isClosed()){
					//System.out.println("exit-status: "+channel2.getExitStatus());
					break;
				}
				try{Thread.sleep(1000);}catch(Exception ee){}
			}

		}catch(Exception e){ 
		}
		finally{
			//check the Unix box is up or not ?
			if((null==tmp)){
				System.out.println("Unable to connect to the server!");
			}
			if(null!=channel1)channel1.disconnect();
			if(null!=channel2)channel2.disconnect();
			if(null!=session)session.disconnect();
		}
	}

}
