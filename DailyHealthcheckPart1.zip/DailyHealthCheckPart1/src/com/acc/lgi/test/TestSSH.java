package com.acc.lgi.test;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.PrintStream;
import java.util.Properties;
import java.util.StringTokenizer;

import com.jcraft.jsch.Channel;
import com.jcraft.jsch.ChannelExec;
import com.jcraft.jsch.ChannelShell;
import com.jcraft.jsch.JSch;
import com.jcraft.jsch.JSchException;
import com.jcraft.jsch.Session;

public class TestSSH {

	public static void main(String[] args) throws IOException, InterruptedException {
		String command = "cd /opt/ibm/ldap/V6.3.1/bin;./ibmdirctl -D cn=root -w '17,|uZnpdIC\\MzAK,.MN' status;";
		//String command="ssh 172.28.48.176";
		/*
		Thread.sleep(1000);
		runNexusCommandViaSSH("vsaripalli01","Rogerthat&7","172.28.48.177","amspichhu00");
		Thread.sleep(2000);
		//runNexusCommandViaSSH("vsaripalli01","Rogerthat&7","172.28.48.176","amspichhu01");
		//Thread.sleep(2000);
		//runNexusCommandViaSSH("vsaripalli01","Rogerthat&7","172.28.48.175","amspichhu02");
		*/	
		Thread.sleep(2000);
		runNexusCommandViaSSH("vsaripalli01","Rogerthat&7","172.28.48.172","amspichhu05");
		Thread.sleep(2000);
		runNexusCommandViaSSH("vsaripalli01","Rogerthat&7","172.28.48.171","amspichhu06");
		Thread.sleep(2000);
		//openSSHNCheckMemoryStatus("vsaripalli01","Rogerthat&7","172.28.48.171","amspichhu06");
		
		//checkMemoryStatusThruAdminSSH("172.28.48.177","amspichhu05","172.28.48.171");
	}

	//openSSHNCheckMemoryStatus("172.28.48.177","amspichhu05","172.28.48.172");

	private static void runNexusCommandViaSSH(String sshuser, String sshpass, String serverIP, String serverHost){
		Channel channel=null;
		Session session=null;
		String line=null;
		String str=null;
		try{
			String strMemoryUsed=null,strMemoryFree=null,strCacheUsed=null,strCacheFree=null,strCmdOutput=null;
			String command1 = "ssh -o \"StrictHostKeyChecking no\" "+serverIP;
			String command2 = "free -m";
			String host="172.28.48.177"; 
			String user="vsaripalli01";
			String password="Rogerthat&7";

			JSch jsch = new JSch();
			session = jsch.getSession(user, host, 22);
			//Properties config = new Properties();	
			//config.put("StrictHostKeyChecking", "no");
			//session.setConfig(config);;
			session.setConfig("StrictHostKeyChecking", "no");
			session.setPassword(password);
			session.connect();

			channel=session.openChannel("shell");
			OutputStream ops = channel.getOutputStream();
			PrintStream ps = new PrintStream(ops, true);

			channel.connect();
			Thread.sleep(1000);
			ps.println(command1);
			Thread.sleep(2000);
			//ps.println("sleep 2s"); //wait for all jobs to finish
			ps.println(command2);
			//ps.println("wait"); //wait for all jobs to finish
			//Thread.sleep(2000);
			ps.println("exit"); //exit from server
			ps.println("exit"); //exit from admin
			ps.close();

			InputStream in=channel.getInputStream();
			byte[] bt=new byte[1024];

			int i=0;
			boolean flag=true;
			while(flag) {				
				while(in.available()>0) {
					flag=false;
					System.out.println("Coming 1..");
					i=in.read(bt, 0, 1024);
					if(i<0)
						break;
					str=new String(bt, 0, i);

					//displays the output of the command executed.
					System.out.print(str);
				}
				System.out.println("Coming 2..");
				if(in.available()< 0) break;
				if(channel.isClosed()) 
					break;

				if(i<0)
					break;
				Thread.sleep(500);
				//channel.disconnect();
				//session.disconnect();   
			}
			Thread.sleep(500);
		}catch(Exception e){
			System.out.println(e.getMessage());
		}finally{
			//check the Unix box is up or not ?
			if((null==str)){
				System.out.println("Unable to connect to the server!");
			}
			if(null!=channel)channel.disconnect();
			if(null!=session)session.disconnect();
		}
	}

	//check memory status of all servers
	private static void openSSHNCheckMemoryStatus(String sshuser, String sshpass, String serverIP, String serverHost) throws IOException {	
		String strMemoryUsed=null,strMemoryFree=null,strCacheUsed=null,strCacheFree=null;
		StringTokenizer str=null;
		Channel channel=null;
		Session session=null;
		byte[] tmp=null;
		//String command1 = "ssh -o \"StrictHostKeyChecking no\" "+serverIP+"&& free -m && exit";
		String command1 = "ssh -o \"StrictHostKeyChecking no\" "+serverIP;
		String command2 = "free -m";
		//String host="172.28.48.177";
		String host="172.28.52.15";
		String user="vsaripalli01";
		String password="Rogerthat&7";
		/*#7 IE SSO Servers
		IESSO1HOSTNAME=amspsdpie00
		IESSO1IPADDRESS=172.28.52.15
		 */

		try{
			java.util.Properties config = new java.util.Properties(); 
			config.put("StrictHostKeyChecking", "no");
			JSch jsch = new JSch();
			session=jsch.getSession(sshuser, host, 22);
			session.setPassword(sshpass);
			session.setConfig(config);
			session.connect();
			System.out.println("Connected");

			channel=session.openChannel("exec");
			((ChannelExec)channel).setCommand(command1);
			channel.setInputStream(null);
			((ChannelExec)channel).setErrStream(System.err);

			InputStream in=channel.getInputStream();
			//OutputStream out=channel.getOutputStream();
			((ChannelExec)channel).setErrStream(System.err);

			channel.connect();
			//out.write((command2+"\n").getBytes());
			//out.write(("logout\n").getBytes());
			//  out.flush();


			tmp=new byte[1024];
			while(true){
				String strCmdOutput;
				//while runs only once, because total o/p is less than 1024 bytes
				while(in.available()>0){ 
					int i=in.read(tmp, 0, 1024);
					if(i<0)break;
					strCmdOutput = new String(tmp, 0, i);
					System.out.print(strCmdOutput);
					String[] parts = strCmdOutput.split("[ ]{2,}");//.split("\\s{2,}");
					//Extract only required values from command output
					strMemoryUsed=parts[8];
					strMemoryFree=parts[9];
					strCacheUsed=parts[13];
					str = new StringTokenizer(parts[14],"Swap:");
					strCacheFree=str.nextToken().trim();
				}
				if(channel.isClosed()){
					//System.out.println("exit-status: "+channel.getExitStatus());
					break;
				}
				try{
					Thread.sleep(1000);
				}catch(Exception e){

				}
			}

		}catch (JSchException e) {

		} 
		finally{
			//check the Unix box is up or not ?
			if((null==tmp)){
			}
			if(null!=channel)channel.disconnect();
			if(null!=session)session.disconnect();
			//System.out.println("Done");
		}
	}

	//check memory status of servers through admin server
	private static void checkMemoryStatusThruAdminSSH(String strAdminServerIP,String strHostName, String strServerIP) {	
		String strMemoryUsed=null,strMemoryFree=null,strCacheUsed=null,strCacheFree=null;
		StringTokenizer str=null;
		Channel channel2=null,channel1=null;;
		Session session=null;
		String command1 = "ssh -o \"StrictHostKeyChecking no\" "+strServerIP;
		String command2 = "free -m";
		byte[] tmp=null;
		try{
			java.util.Properties config = new java.util.Properties(); 
			config.put("StrictHostKeyChecking", "no");
			JSch jsch = new JSch();
			session=jsch.getSession("vsaripalli01",strAdminServerIP, 22);
			session.setPassword("Rogerthat&7");
			session.setConfig(config);
			session.connect();

			channel1=session.openChannel("exec");
			channel2=session.openChannel("exec");

			((ChannelExec)channel1).setCommand(command1);
			channel1.setInputStream(null);
			((ChannelExec)channel2).setCommand(command2);
			channel2.setInputStream(null);
			((ChannelExec)channel2).setErrStream(System.err);

			//InputStream in1=channel1.getInputStream();
			channel1.connect();

			InputStream in=channel2.getInputStream();
			channel2.connect();

			tmp=new byte[1024];
			while(true){
				String strCmdOutput;
				//while runs only once, because total o/p is less than 1024 bytes
				while(in.available()>0){ 
					int i=in.read(tmp, 0, 1024);
					if(i<0)break;
					strCmdOutput = new String(tmp, 0, i);
					System.out.print(strCmdOutput);
					String[] parts = strCmdOutput.split("[ ]{2,}");//.split("\\s{2,}");
					//Extract only required values from command output
					strMemoryUsed=parts[8];
					strMemoryFree=parts[9];
					strCacheUsed=parts[13];
					str=new StringTokenizer(parts[14],"Swap:");
					strCacheFree=(str.nextToken()).trim();
				}
				if(channel2.isClosed()){
					//System.out.println("exit-status: "+channel2.getExitStatus());
					break;
				}
				try{Thread.sleep(1000);}catch(Exception ee){}
			}
			/*
					//write memory status results to excel
					columnCount=0;
					row = sheet[sheetIndex].createRow(++rowCount);
					cell = row.createCell(++columnCount);
					cell.setCellValue(strHostName);
					cell = row.createCell(++columnCount);
					cell.setCellValue(strServerIP);
					cell = row.createCell(++columnCount);
					cell.setCellValue(strMemoryUsed);
					cell = row.createCell(++columnCount);
					cell.setCellValue(strMemoryFree);
					cell = row.createCell(++columnCount);
					cell.setCellValue(strCacheUsed);
					cell = row.createCell(++columnCount);
					cell.setCellValue(strCacheFree); */

		}catch (JSchException e){ 
		}
		catch (IOException e1) {
			e1.printStackTrace();}
		catch(Exception e){ }
	finally{
		//check the Unix box is up or not ?
		if((null==tmp)){
			System.out.println("Unable to connect to the server!");
		}
		if(null!=channel1)channel1.disconnect();
		if(null!=channel2)channel2.disconnect();
		if(null!=session)session.disconnect();
	}
}
}
