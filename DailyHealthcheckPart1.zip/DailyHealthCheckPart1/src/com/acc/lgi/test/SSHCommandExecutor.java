package com.acc.lgi.test;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStream;
import java.util.StringTokenizer;

import com.jcraft.jsch.Channel;
import com.jcraft.jsch.ChannelExec;
import com.jcraft.jsch.JSch;
import com.jcraft.jsch.JSchException;
import com.jcraft.jsch.Session;

public class SSHCommandExecutor {
	static File file1=null,file2=null;
	static FileReader fr;
	static FileWriter fw;
	static BufferedReader br;
	static BufferedWriter bw;

	//check memory status of all servers
	private static void openSSHNCheckMemoryStatus(String strServerIP) {	
		try {
			file2.createNewFile();
			fw = new FileWriter(file2.getAbsoluteFile());
			bw = new BufferedWriter(fw);
		} catch (IOException e1) {
			e1.printStackTrace();
		}

		Channel channel=null;
		Session session=null;
		byte[] tmp=null;
		try{
			java.util.Properties config = new java.util.Properties(); 
			config.put("StrictHostKeyChecking", "no");
			JSch jsch = new JSch();
			session=jsch.getSession("skatta", strServerIP, 22);
			session.setPassword("Aurora@123");
			session.setConfig(config);
			session.connect();
			//System.out.println("Connected");

			channel=session.openChannel("exec");
			((ChannelExec)channel).setCommand("free -m");
			channel.setInputStream(null);
			((ChannelExec)channel).setErrStream(System.err);

			InputStream in=channel.getInputStream();
			channel.connect();
			tmp=new byte[1024];
			while(true){
				String strCmdOutput;
				//while runs only once, because total o/p is less than 1024 bytes
				while(in.available()>0){ 
					int i=in.read(tmp, 0, 1024);
					if(i<0)break;
					strCmdOutput = new String(tmp, 0, i);
					//System.out.print(strCmdOutput);
					String[] parts = strCmdOutput.split("[ ]{2,}");//.split("\\s{2,}");
					int l=parts.length;
					//Extract only required values from command output
					System.out.println(strServerIP+","+parts[l-2]+","+parts[l-1]);
				}
				if(channel.isClosed()){
					//System.out.println("exit-status: "+channel.getExitStatus());
					break;
				}
				try{Thread.sleep(1000);}catch(Exception ee){}
			}
			//write memory status results to excel
			//strHostName strServerIP strMemoryUsed strMemoryFree strCacheUsed strCacheFree

		}catch (JSchException e) {
		} catch (IOException e) {
			e.printStackTrace();
		} catch(Exception e){
		}
		finally{
			//check the Unix box is up or not ?
			if((null==tmp)){
				System.out.println("Unable to connect to the server : "+strServerIP);
				try {
					bw.write("Unable to connect to the server : "+strServerIP);
				} catch (IOException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
			if(null!=channel)channel.disconnect();
			if(null!=session)session.disconnect();
			//System.out.println("DONE");
		}
	}

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		String textLine;
		try{
			System.out.println("[Info]:started");
			file1 = new File("C:\\Users\\vcherukuri\\Desktop\\SSO\\temp\\file1.txt");
			file2 = new File("C:\\Users\\vcherukuri\\Desktop\\SSO\\temp\\OutputFile2.csv");
			//check if input file exists or not ?
			if (!(file1.exists())) {
				System.out.println("Error : File1 doesn't exists!!");
				//System.exit(0);
				return;
			}
			fr = new FileReader(file1.getAbsoluteFile());
			br = new BufferedReader(fr);
			//file2 = new File(file2);

			while((textLine=br.readLine())!=null)
			{
				openSSHNCheckMemoryStatus(textLine.trim());				
			}
		}catch(Exception e){
			e.printStackTrace();
		}
		finally{
			
			try {
				if(null!=br){br.close();}
				if(null!=bw){bw.close();}				
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		System.out.println("[Info]:Done");
	}

}